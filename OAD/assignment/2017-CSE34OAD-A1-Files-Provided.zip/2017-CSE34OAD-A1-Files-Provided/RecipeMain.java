import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.geometry.*;
import java.util.*;
import java.io.*;
import javafx.collections.*;
import javafx.collections.transformation.*;
import javafx.scene.control.cell.*;
import javafx.beans.property.*;

public class RecipeMain extends Application
{
	private ObservableList<Recipe> tableData;
	private TableView<Recipe> tableView;
	private RecipeDSC recipeDSC;

	public void start(Stage primaryStage) throws Exception
	{
		build(primaryStage);
		primaryStage.setTitle(getClass().getName());
		primaryStage.show();

		Thread.currentThread().setUncaughtExceptionHandler((thread, exception) ->
		{
			// System.out.println("ERROR: " + exception);
			Alert alert = new Alert(Alert.AlertType.WARNING);
			alert.setContentText("Exception thrown: " + exception);
			alert.showAndWait();
		});
	}

	public void build(Stage primaryStage) throws Exception
	{
		loadData();

		Node searchArea = makeSearchArea();
		Node tableViewArea = makeTableView();
		Node addViewDeleteArea = makeViewAddDeleteArea(primaryStage);

		VBox root = makeSceneRoot();

		root.getChildren().addAll(searchArea, tableViewArea, addViewDeleteArea);

		Scene scene = new Scene(root);
		primaryStage.setScene(scene);
	}


	// To load data from the database into tableData
	// and tableView
	//
	private void loadData() throws Exception
	{
		recipeDSC = new RecipeDSC();
		List<Recipe> recipes = recipeDSC.findAll();

		tableData = FXCollections.observableArrayList();
		tableData.clear();
		tableData.addAll(recipes);

		tableView = new TableView<Recipe>();
		tableView.setItems(tableData);
	}


	// TO DO: Create and return a VBox to be the root of the scene graph
	//
	private VBox makeSceneRoot()
	{
		return null;
	}


	// TO DO: Create the area to allow the user to search the table view
	// The program should provide option to apply the search to every field, or
	// to the ingredients, or the recipe names.
	//
	private Node makeSearchArea()
	{
		  return null;
	}


	//
	// TO DO: Define the table view and put it in a hbox
	//
	private Node makeTableView()
	{
		return null;
	}


	// TO DO: Create the area with the buttons to view, add and delete reviews
	//
	private Node makeViewAddDeleteArea(Stage primaryStage)
	{
		return null;
	}

}

