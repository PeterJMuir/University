/*
This class is used to define and show three stages: one to view and/od update
a recipe, one to add a ne recipe, and one to delete a recipe.
*/

import javafx.application.Application;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.geometry.*;
import java.util.*;
import java.io.*;
import javafx.collections.*;
import javafx.collections.transformation.*;
import javafx.scene.control.cell.*;
import javafx.beans.property.*;

public class RecipeStageMaker
{
	private RecipeDSC recipeDSC;
	private ObservableList<Recipe> tableData;
	private TableView<Recipe> tableView;
	private Stage primaryStage;

	// id
	private Label idLB = new Label("Id: ");
	private TextField idTF = new TextField();
	private HBox idHBox = new HBox(idLB, idTF);

	// name
	private Label nameLB = new Label("Recipe Name: ");;
	private TextField nameTF = new TextField();
	private HBox nameHBox = new HBox(nameLB, nameTF);

	// serves
	private Label servesLB = new Label("Serves: ");
	private TextField servesTF = new TextField();
	private HBox servesHBox = new HBox(servesLB, servesTF);

	// ingredients
	private Label ingredientsLB = new Label("Ingredients");
	private TableView<Ingredient> ingredientsTbl = new TableView<>();
	private Button ingredientsAdd = new Button("Add Ingredient");
	private Button ingredientsEdd = new Button("Edit Ingredient");
	private Button ingredientsDel = new Button("Delete Ingredient");
	private VBox ingredientButtons = new VBox(ingredientsAdd, ingredientsEdd, ingredientsDel);
	private VBox ingredientsLblAndTbl = new VBox(ingredientsLB, ingredientsTbl);
	private HBox ingredientsHBox = new HBox(ingredientsLblAndTbl, ingredientButtons);

	// steps
	private TextArea stepsTA = new TextArea();
	private HBox stepsHBox = new HBox(stepsTA);

	// remarks
	private Label remarksLB = new Label("Remarks: ");
	private TextField remarksTF = new TextField();
	private HBox remarksHBox = new HBox(remarksLB, remarksTF);

	// action buttons
	private Button addBT = new Button("ADD Recipe");
	private Button updateBT = new Button("UPDATE Recipe");
	private Button deleteBT = new Button("DELETE Recipe");
	private Button cancelBT = new Button("EXIT/CANCEL");
	private HBox actionHBox = new HBox();

	// root, scene, local stage
	private VBox root = new VBox();
	private Scene scene = new Scene(root);
	private Stage stage = new Stage();

	public RecipeStageMaker(RecipeDSC recipeDSC, ObservableList<Recipe> tableData, TableView<Recipe> tableView, Stage primaryStage )
	{
		/*
		 * TO DO: Initilize the RecipeStageMaker
		 * (can include the setting of style rules if choose to do so)
		 */
	}

	public void showViewRecipeStage()
	{
		/*
		 * TO DO: To present a stage to view and/or update the recipe selected
		 * in the table view
		 */
	}

	public void showAddRecipeStage()
	{
		/*
		 * TO DO: To present a stage to add a recipe
		 */
	}

	public void showDeleteRecipeStage()
	{
		/*
		 * TO DO: To present a stage to delete the recipe selected in
		 * the table view
		 */
	}
}
