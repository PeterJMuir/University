//	This version does not use TableView
//

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.stage.*;	// Modality

import java.util.*;	// List

public class MusicCatalogFXVersion1 extends Application
{
	private static final String DATA_FILE_NAME = "MusicCatalog.dat";

	private MusicCatalogDS catalogDS = new MusicCatalogDS();

	private TextArea displayTA = new TextArea();
	private TextField idTF = new TextField();
	private TextField nameTF = new TextField();
	private TextField genreTF = new TextField();
	private TextField isCompilationTF = new TextField();
	private TextField trackCountTF = new TextField();

	public void start(Stage stage) throws Exception
	{
		build(stage);
		stage.setTitle(getClass().getName());
		stage.show();

		Thread.currentThread().setUncaughtExceptionHandler((thread, exception) ->
			{
				System.out.println("ERROR: " + exception);
				Alert alert = new Alert(Alert.AlertType.INFORMATION);
				alert.setContentText("ERROR: " + exception);
				alert.showAndWait();
			});
	}

	public void build(Stage primaryStage) throws Exception
	{
		//	Text area

		displayTA.setMinWidth(200);
		displayTA.setMinHeight(200);

		// 5 rows of labels and text fields

		Label idLB = new Label("ID: ");
		idTF = new TextField();
		HBox idHBox = new HBox();
		idHBox.getChildren().addAll(idLB, idTF);

		Label nameLB = new Label("Name: ");
		nameTF = new TextField();
		HBox nameHBox = new HBox();
		nameHBox.getChildren().addAll(nameLB, nameTF);

		Label genreLB = new Label("Genre: ");
		genreTF = new TextField();
		HBox genreHBox = new HBox();
		genreHBox.getChildren().addAll(genreLB, genreTF);

		Label isCompilationLB = new Label("Is Compilation: ");
		isCompilationTF = new TextField();
		HBox isCompilationHBox = new HBox();
		isCompilationHBox.getChildren().addAll(isCompilationLB, isCompilationTF);

		Label trackCountLB = new Label("TrackCount: ");
		trackCountTF = new TextField();
		HBox trackCountHBox = new HBox();
		trackCountHBox.getChildren().addAll(trackCountLB, trackCountTF);

		// button to perform operations
		//
		Button loadDataBT = new Button("Load Data");
		Button displayAlbumsBT = new Button("Display Albums");
		Button searchAlbumBT = new Button("Search Album");
		Button addAlbumBT = new Button("Add Album");
		Button removeAlbumBT = new Button("Remove Album");
		Button saveDataBT = new Button("SaveData");

		FlowPane buttonsPane = new FlowPane();
		buttonsPane.getChildren().addAll(loadDataBT, displayAlbumsBT,
			searchAlbumBT, addAlbumBT, removeAlbumBT, saveDataBT);

		//	root to contain text area, work area and operation buttons
		//
		VBox root = new VBox();
		root.getChildren().addAll(displayTA, idHBox, nameHBox, genreHBox, isCompilationHBox,
			trackCountHBox, buttonsPane);
		root.setStyle("-fx-alignment: center; -fx-font-size: 20; -fx-spacing: 20");

		Scene scene = new Scene(root, 600, 600);
		primaryStage.setScene(scene);



		// Implement behaviors

		// Load data
		loadDataBT.setOnAction((e) -> loadData(DATA_FILE_NAME));

		// Display albums
		displayAlbumsBT.setOnAction((e) -> displayAlbums());


		// Search Album
		searchAlbumBT.setOnAction((e) -> searchAlbum());


		// Add album
		addAlbumBT.setOnAction((e) -> addAlbum());

		// Remove album
		removeAlbumBT.setOnAction((e) -> removeAlbum());

		// Save data
		saveDataBT.setOnAction((e) -> saveData(DATA_FILE_NAME));
	}

	private void loadData(String fileName)
	{
		try
		{
			catalogDS.loadData(fileName);
			System.out.println("\nLOAD DATA:\n" + catalogDS);	// to verify
		}
		catch(Exception exception)
		{
			throw new RuntimeException(exception.getMessage());
		}
	}


	private void displayAlbums()
	{
		List<MusicAlbum> list = catalogDS.getAll();
		String lines = "";
		for(MusicAlbum album: list)
		{
			lines += album.toString() + "\n";
		}

		displayTA.setText(lines);
	}

	private void searchAlbum()
	{
		String id = idTF.getText();
		MusicAlbum album = catalogDS.get(id);

		nameTF.setText(album.getName());
		genreTF.setText(album.getGenre() + "");
		isCompilationTF.setText(album.isCompilation() + "");
		trackCountTF.setText(album.getTrackCount() + "");

		displayTA.setText(album.toString());
		// System.out.println(album);
	}


	private void addAlbum()
	{
		String id = idTF.getText().trim();
		String name = nameTF.getText().trim();
		String genre = genreTF.getText().trim();
		boolean isCompilation = Boolean.parseBoolean(isCompilationTF.getText().trim());
		int trackCount = Integer.parseInt(trackCountTF.getText().trim());
		System.out.println(">>> " + trackCount);

		try
		{
			MusicAlbum album = new MusicAlbum(id, name, genre, isCompilation, trackCount);
			System.out.println(">>> " + album);
			catalogDS.add(album);
		}
		catch(Exception exception)
		{
			throw new RuntimeException(exception.getMessage());
		}

		System.out.println("\nADD PRODUCT:\n" + catalogDS); // to check
	}

	private void removeAlbum()
	{
		String id = idTF.getText().trim();

		try
		{
			catalogDS.remove(id);
		}
		catch(Exception exception)
		{
			throw new RuntimeException(exception.getMessage());
		}

		System.out.println("\nRemove album " + id + "\n" + catalogDS); // to check
	}

	private void saveData(String fileName)
	{
		try
		{
			catalogDS.saveData(fileName);
		}
		catch(Exception exception)
		{
			throw new RuntimeException(exception.getMessage());
		}

		System.out.println("\nSAVE DATA:\n" + catalogDS); // to check
	}
}

