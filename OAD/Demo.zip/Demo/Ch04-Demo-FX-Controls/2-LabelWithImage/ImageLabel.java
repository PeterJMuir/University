import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import javafx.scene.text.*;		// Font
import javafx.scene.paint.*;	// Color
import javafx.geometry.*;		// Pos
import javafx.scene.image.*;	// ImageView

public class ImageLabel extends Application
{
	private int count = 0;

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.sizeToScene();
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Define image view
		ImageView imgView = new ImageView("picture.jpg");
		imgView.setFitWidth(100);
		imgView.setPreserveRatio(true);

		// Define label
		Label label = new Label("Best Friend", imgView);
		label.setContentDisplay(ContentDisplay.TOP);	// image on top of text
		label.setStyle("-fx-border-style:solid");		// draw border


		// Define tooltip
		label.setTooltip(new Tooltip("This is tooltip message"));


		// Register a mouse event handler
		label.setOnMouseEntered( e ->
			{
				System.out.println(">> I am a mini fox terrier.");
			});

		// Add label to pane
		FlowPane pane = new FlowPane(label);
		pane.setAlignment(Pos.CENTER);

		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}
}
