import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

import javafx.scene.paint.*;
import javafx.geometry.*;

public class ButtonBasics extends Application
{
	private int count;
 		// Need to make count an attribute
 		// so that it can be accessed by lambda expression

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Create button
		Button button = new Button("A Button");

		// Set text font and color, background color, draw border
		button.setFont(Font.font("Arial", 30));
		button.setTextFill(Color.RED);
		button.setStyle("-fx-background-color: yellow;");
		button.setStyle(button.getStyle() + "-fx-border-style:solid;");

		// Set size
		button.setMinWidth(200);
		button.setMinHeight(100);

		// Set text alignment
		button.setAlignment(Pos.CENTER_LEFT);

		// Register an action event listener
		count = 0;
		button.setOnAction(e ->
			{
				count++;
				button.setText("Times Clicked: " + count);
			});

		// set tooltip and event listener
		button.setTooltip(new Tooltip("This is a tooltip"));
		button.setOnMouseExited((e) -> System.out.println("Mouse exited"));

		// For a quick and dirty test
		// Uncomment and see effect
		button.setDisable(true);

		// Put button in a pane
		FlowPane pane = new FlowPane(button);
		pane.setAlignment(Pos.CENTER);

		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}
}
