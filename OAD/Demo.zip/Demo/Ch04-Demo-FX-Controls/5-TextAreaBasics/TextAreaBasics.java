import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

import javafx.scene.paint.*;
import javafx.geometry.*;
import javafx.scene.image.*;	// ImageView
import javafx.scene.Node;

public class TextAreaBasics extends Application
{
	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.sizeToScene();
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Create a text area
		TextArea ta = new TextArea();

		// Put some text in
		ta.setText("This is line 1\n");
		ta.appendText("This is line 2\n");

		// Set wrapping to true
		ta.setWrapText(true);

		// Can cut and paste text in text area

		// Scrollbars are provided if necessary


		// A button to display text
		//
		Button displayBT = new Button("Display Text");
		displayBT.setOnAction((e) ->
			{
				System.out.println(ta.getText());
			});

		// A text area with non-default font, color , size
		//
		TextArea ta2 = new TextArea();
		ta2.setMaxWidth(150);
		ta2.setMaxHeight(150);
		ta2.setFont(Font.font("Arial", 20));
		ta2.setStyle("-fx-text-fill: red;");
		ta2.setStyle(ta2.getStyle()
			+ "-fx-background-color: yellow;"); // effect?



		// Use a vbox to display text areas
		VBox pane = new VBox(ta, displayBT, ta2);
		pane.setAlignment(Pos.CENTER);
		pane.setSpacing(10);

		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 300);

		ta2.requestFocus();
			// Initially cursor is placed in this text area

		stage.setScene(scene);
	}
}
