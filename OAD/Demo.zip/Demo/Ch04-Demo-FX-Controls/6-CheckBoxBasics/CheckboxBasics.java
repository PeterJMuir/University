import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.geometry.*;

public class CheckboxBasics extends Application
{
	private int count = 0;

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Define checkbox 1
		//
		CheckBox cb1 = new CheckBox("Check Box 1");
		cb1.setFont(Font.font("Monospace", 20));
		cb1.setStyle("-fx-background-color: yellow;");
		cb1.setMinWidth(200);
		// cb1.setDisable(true);

		// Define button to display state of check bx 1
		//
		Button displayBT = new Button("Display check box state");
		displayBT.setOnAction((e) ->
			{
				boolean state = cb1.isSelected();
				System.out.println("Check box 1 selected: " + state);
			});

		HBox hbox1 = new HBox(40, cb1, displayBT);

		// Define check box 2
		//
		CheckBox cb2 = new CheckBox();
		cb2.setText("Check Box 2");

		// Define a button to toggle check box 2
		//
		Button toggleBT = new Button("Toggle Check Box 2");
		toggleBT.setOnAction((e) ->
			{
				boolean state = cb2.isSelected()? false: true;
				cb2.setSelected(state);
				System.out.println("Check box 2 selected: " + state);
			});

		HBox hbox2 = new HBox(40, toggleBT, cb2);

		// Define check box 3 (and put the label on the left)
		CheckBox cb3 = new CheckBox();
		Label lb = new Label("Disable the button");
		lb.setGraphic(cb3);
		lb.setContentDisplay(ContentDisplay.RIGHT); // RIGHT,LEFT,TOP,BOTTOM

		// Define a button
		// Set a listener so that we can use check box 3
		// to turn the button on/off
		//
		Button bt = new Button("On/Off");
		cb3.setOnAction((e) ->
			{
				bt.setDisable(cb3.isSelected());
				System.out.println("Button disabled: " + bt.isDisable());
			});

		HBox hbox3 = new HBox(40, lb, bt);

		// Define a vbox to holds the controls
		//
		VBox vbox = new VBox(hbox1, hbox2, hbox3);
		vbox.setSpacing(30);

		//	Set scene and stage
		Scene scene = new Scene(vbox, 400, 300);
		stage.setScene(scene);
	}
}
