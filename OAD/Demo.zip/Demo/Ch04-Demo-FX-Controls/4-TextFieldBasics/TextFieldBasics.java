import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

import javafx.scene.paint.*;
import javafx.geometry.*;

public class TextFieldBasics extends Application
{
	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Create text fields
		TextField tf = new TextField("Text Field ");

		// Set font
		tf.setFont(Font.font("Arial", 20));

		// Set text color
		tf.setStyle("-fx-text-fill: red;");

		// Set background color and border
		tf.setStyle(tf.getStyle() + "-fx-background-color: yellow;");
		tf.setStyle(tf.getStyle() + "-fx-border-style:solid;");

		// Set size
		tf.setMinWidth(200);
		tf.setMinHeight(100);

		// Set alignment of text in text field
		tf.setAlignment(Pos.CENTER_LEFT);

		// A button to "double" the text in the text field
		//
		Button appendBT = new Button("Append Text");
		appendBT.setOnAction(e ->
			{
				tf.appendText(tf.getText());
			});

		// To illustrate setEditable
		//
		TextField tf2 = new TextField("You cannot change me");
		tf2.setEditable(false);

		// To illustrate set focus
		//
		TextField tf3 = new TextField("Text Field 3");
		tf3.setMaxWidth(200);

		// Example of password field
		//
		PasswordField pwf = new PasswordField();

		// Use a vbox to display buttons
		VBox pane = new VBox(tf, appendBT, tf2, tf3, pwf);
		pane.setAlignment(Pos.CENTER);
		pane.setSpacing(20);

		//Set scene and stage
		Scene scene = new Scene(pane, 400, 300);
		tf3.requestFocus(); // must be after placing it in the scene

		stage.setScene(scene);
	}
}
