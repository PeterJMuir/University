import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

import javafx.collections.*;
import java.util.*;

public class ChoiceBoxDemo extends Application
{
	private int count = 0;

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle("Sample");
		stage.sizeToScene();
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Define a list of Strings (objetcs)
		String choice1 = "Choice 1";
		String choice2 = "Choice 2";
		String choice3 = "Choice 3";
		String choice4 = "Choice 4";

		// Create a choice box and add the strings as its item
		ChoiceBox<String>  choices = new ChoiceBox<String>();
		choices.getItems().addAll(choice1, choice2, choice3, choice4);

		// Set the default value
		choices.setValue(choice2);

		// Create a button to get selected value
		//
		Button bt = new Button("Get Choice");
		bt.setOnAction((e) ->
			{
				String selected = choices.getValue();
				System.out.println(selected);
			});

		// Put the controls in a pane
		FlowPane pane = new FlowPane(choices, bt);
		pane.setHgap(20);

		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}
}
