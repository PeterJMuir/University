import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.geometry.*;

public class RadioButtonDemo extends Application
{
	private int count = 0;

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Define radio buttons
		//
		RadioButton smallRB = new RadioButton("Small");
		RadioButton medRB = new RadioButton("Medium");
		RadioButton largeRB = new RadioButton("Large");

		//	Add them to a toggle group
		//
		ToggleGroup group = new ToggleGroup();
		smallRB.setToggleGroup(group);
		medRB.setToggleGroup(group);
		largeRB.setToggleGroup(group);

			largeRB.setToggleGroup(null);
			// Remove button from the group

		// Add a button to get the selected radio button
		//
		Button bt = new Button("Get Selected Button");
		bt.setOnAction((e) ->
			{
				RadioButton selected = (RadioButton) group.getSelectedToggle();
				System.out.println(selected);
				System.out.println(selected.getText());
			});

		// Add the radio buttons and the "action" button to a pane
		// Note that we don't add the toggle group. Why?
		//
		FlowPane pane = new FlowPane(smallRB, medRB, largeRB, bt);
		pane.setHgap(20);

		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}
}
