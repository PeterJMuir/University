import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

import javafx.scene.paint.*;
import javafx.geometry.*;
import javafx.scene.image.*;	// ImageView

public class LabelBasics extends Application
{
	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Create label
		Label lb1 = new Label("Label 1");
		Label lb2 = new Label("Label 2");

		// Set font
		lb1.setFont(Font.font("Arial", 30));

		// Set text color
		lb1.setTextFill(Color.RED);

		// Set background color
		lb1.setStyle("-fx-background-color: yellow;");

		// Set border (in addition to set style earlier)
		lb1.setStyle(lb1.getStyle()
			+ "-fx-border-style:solid;"
			+ "-fx-border-color:blue;"
			+ "-fx-border-width:5;"
			+ "-fx-border-radius: 5, 5, 5, 5;");

		// Set size
		lb1.setMinWidth(200);
		lb1.setMaxWidth(100);

		lb1.setMinHeight(100);
		lb1.setMaxWidth(100);

				// lb1.setWidth(100); ILLEGAL
				// setWidth has protected access!!!
				// Can also use setPrefWidth, etc.

		// Set alignment of text within label's space
		lb1.setAlignment(Pos.CENTER_RIGHT);
				// vertically center, horizontally right


		lb1.setTooltip(new Tooltip("Tooltip for Label"));

		lb1.setOnMouseEntered((e) -> {System.out.println("Mouse entered label");});


		// Use a vbox to display lables
		VBox box = new VBox();
		box.setMinWidth(300);
		box.setMaxWidth(300);
		box.setAlignment(Pos.CENTER);	// to position controls
		box.setStyle("-fx-border-style:solid; -fx-border-color: blue;"
			+ "-fx-border-width: 10;");
		box.getChildren().add(lb1);
		box.setStyle(box.getStyle() + "-fx-background-color: red;");

		VBox b2 = new VBox(new Button("Another one"));

		Label l3 = new Label("L 3");
		l3.setTooltip(new Tooltip(" for label l3"));

		Pane pane = new FlowPane(box, b2, l3);

		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}
}
