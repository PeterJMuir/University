import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

import javafx.scene.paint.*;
import javafx.geometry.*;

public class SampleFX extends Application
{
	private int count = 0;

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.sizeToScene();
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Define controls and layout
		Label lb1 = new Label("Label 1");
		Label lb2 = new Label("Label 2");
		Label lb3 = new Label("Label 3");
		Label lb4 = new Label("Label 4");

		lb1.setFont(Font.font("Arial", 30));

		lb1.setTextFill(Color.RED);

		lb1.setPrefWidth(200);
		// lb1.setMinWidth(200);
		// lb1.setMaxWidth(200);

		lb1.setAlignment(Pos.CENTER_RIGHT);			// within space of label itself

		lb1.setStyle("-fx-border-style:solid");	// set border


		lb2.setPrefWidth(100);
		lb2.setStyle("-fx-border-style:solid");

		VBox pane = new VBox();
		pane.setMinWidth(200);
		pane.setMaxWidth(200);
		pane.setAlignment(Pos.CENTER);
		pane.setStyle("-fx-border-style:solid");
		pane.getChildren().addAll(lb1, lb2, lb3, lb4);

		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}
}
