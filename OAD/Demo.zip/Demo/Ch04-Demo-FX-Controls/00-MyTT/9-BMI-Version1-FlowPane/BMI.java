import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.scene.paint.*;	// e.g. Color

public class BMI extends Application
{
	private int count = 0;

	public void start(Stage stage)
	{
		stage.setTitle(getClass().getName());
		stage.sizeToScene();
		addContents(stage);
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Define controls
		Text header = new Text("BMI Calculator");
		header.setFont(new Font(40));

		Label heightLB = new Label("Enter your height (in cm): ");
		TextField heightTF = new TextField();

		Label weightLB = new Label("Enter your weight (in kg): ");
		TextField weightTF = new TextField();

		Button calculateBT = new Button("Calculate");

		Text bmiText = new Text("Your BMI result will be displayed here");

		calculateBT.setOnAction(e ->
			{
				double height = Double.parseDouble(heightTF.getText().trim())/100;
				int weight = Integer.parseInt(weightTF.getText().trim());
				double bmi = weight / (height * height);
				bmiText.setText("Your bmi is: " + String.format("%.2f", bmi));
			});

		TextArea infoTA = new TextArea();
		infoTA.appendText(
			"A BMI of 18.5 to 25 may indicate optimal weight\n" +
			"A BMI lower than 18.5 suggests the person is underweight\n" +
			"A BMI above 25 may indicate the person is overweight\n" +
			"A BMI above 30 suggests the person is obese");

		// Define layout
		Pane pane = new FlowPane();
		pane.getChildren().add(header);
		pane.getChildren().add(heightLB);
		pane.getChildren().add(heightTF);
		pane.getChildren().add(weightLB);
		pane.getChildren().add(weightTF);
		pane.getChildren().add(calculateBT);
		pane.getChildren().add(bmiText);
		pane.getChildren().add(infoTA);

		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}
}
