import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.stage.Modality;

public class ConfirmationDialogTester extends Application
{
	boolean response;

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.sizeToScene();
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Define controls and layout
		Button messageBoxBT = new Button("Click to show message box");
		messageBoxBT.setOnAction((e) ->
			{
				response = ConfirmationDialog.show("Confirm this message?");
				System.out.println(response);
			});

		Pane pane = new FlowPane();
		pane.getChildren().add(messageBoxBT);

		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}
}
