import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;

public class ConfirmationDialog
{
	static boolean response = false;

	public static boolean show(String message)
	{
		// Create a stage without the usual window buttons
		// In particular, we don't want the close button
		//
		Stage stage = new Stage(StageStyle.UNDECORATED);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setMinWidth(250);

		Label lbl = new Label();
		lbl.setText(message);

		Button yesBT = new Button();
		yesBT.setText("YES");
		yesBT.setOnAction(e ->
			{
				response = true;
				stage.close();
			});

		Button noBT = new Button();
		noBT.setText("NO");
		noBT.setOnAction(e ->
			{
				response = false;
				stage.close();
			});
		VBox pane = new VBox(20);
		pane.getChildren().addAll(lbl, yesBT, noBT);
		pane.setAlignment(Pos.CENTER);

		// To draw a border
		// (otherwise, we don't have a border!)
		//
		pane.setStyle("-fx-border-style:solid;"
			+ "-fx-background-color:lightgray;"
			+ "-fx-padding: 10px");

		Scene scene = new Scene(pane);
		stage.setScene(scene);
		stage.showAndWait();
		return response;
	}
}
