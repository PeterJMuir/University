import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

public class SwitchScenes extends Application
{
	public void start(Stage stage)
	{
		stage.setTitle("Scene Switching Demo");
		stage.sizeToScene();
		addContents(stage);
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Make stage refer to the stage instance that the runtime system
		// created and passed to the start method
		// this.stage = stage;

		// Define controls and scene for scene 1
		Label scene1LB = new Label("Hello!");
		scene1LB.setFont(Font.font("Arial", 40));
		Button scene1SwitchBT = new Button("Switch Scene");
		VBox box1 = new VBox();
		box1.getChildren().addAll(scene1LB, scene1SwitchBT);
		Scene scene1 = new Scene(box1);

		// Define controls and scene for scene 2
		Label scene2LB = new Label("How are you!");
		scene2LB.setFont(Font.font("Arial", 40));
		Button scene2SwitchBT = new Button("Switch Scene");
		VBox box2 = new VBox();
		box2.getChildren().addAll(scene2LB, scene2SwitchBT);
		Scene scene2 = new Scene(box2);

		// Define scene switching response
		scene1SwitchBT.setOnAction((e) ->
			{
				stage.setScene(scene2);
			});

		scene2SwitchBT.setOnAction((e) ->
			{
				stage.setScene(scene1);
			});

		// Intially let the stage show scene1
		stage.setScene(scene1);
	}
}
