import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;

public class MessageDialog
{
	public static void show(String message)
	{
		// Create a stage without the usual window buttons
		// In particular, we don't want the close button
		//
		Stage stage = new Stage(StageStyle.UNDECORATED);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setMinWidth(250);

		Label lbl = new Label();
		lbl.setText(message);

		Button btnOK = new Button();
		btnOK.setText("OK");
		btnOK.setOnAction(e -> stage.close());

		VBox pane = new VBox(20);
		pane.getChildren().addAll(lbl, btnOK);
		pane.setAlignment(Pos.CENTER);

		// To draw a border
		// (otherwise, we don't have a border!)
		//
		pane.setStyle("-fx-border-style:solid;"
			+ "-fx-background-color:lightgray;"
			+ "-fx-padding: 10px");

		Scene scene = new Scene(pane);
		stage.setScene(scene);
		stage.showAndWait();
	}
}
