import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

import javafx.scene.paint.*;
import javafx.geometry.*;

public class LabelBasics extends Application
{
	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Create label
		Label label = new Label("A LABEL");
				// Label label = new Label();
				// label.setText("A LABEL");

		// Set text font and color
		label.setFont(Font.font("Arial", 30));
		label.setTextFill(Color.RED);

		// Set background color
		// CSS-based style
		label.setStyle("-fx-background-color: yellow;");

		// Set size
		label.setMinWidth(200);
		label.setMaxWidth(200);
		label.setPrefHeight(100);

		// Set alignment
		// to position text within space of label itself
		// Try other alignment options and see the effect
		label.setAlignment(Pos.CENTER_LEFT);
				// TOP_LEFT, TOP_CENTER, TOP_RIGHT, etc.

		// Set border
		// Note the use of getStyle()
		label.setStyle(
			label.getStyle() +
			"-fx-border-style:solid;");


		// Set tooltip
		label.setTooltip(new Tooltip("This is a tooltip"));

		// Register a mouse listener
		// This listener listens to the event of the mouse
		// entering the space occupied by the label
		//
		label.setOnMouseEntered((e) ->
			{
				System.out.println("Mouse enters label area");
			});

		// Place the label in the pane
		FlowPane pane = new FlowPane(label);

		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}
}
