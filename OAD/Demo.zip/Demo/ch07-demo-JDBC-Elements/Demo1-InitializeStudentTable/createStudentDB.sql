-- create an empty database StudentDB
drop database if exists StudentDB;
create database StudentDB;