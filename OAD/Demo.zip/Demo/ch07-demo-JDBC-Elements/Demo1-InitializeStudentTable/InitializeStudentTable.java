import java.sql.*;

public class InitializeStudentTable
{
	public static void main(String [] args) throws Exception
	{
	  	// prepare to connect to MySQL database
	  	String databaseURL = "jdbc:mysql://localhost:3306/StudentDB";
		String username = "";
		String password = "";
	  	Connection connection = null;
	  	Statement statement = null;

	  	try
	  	{
			// connect to the database
			connection = DriverManager.getConnection(databaseURL, username, password );

			// create a statement object
			statement = connection.createStatement();

			// execute statements to drop the tables if they exist
			statement.executeUpdate("drop table if exists Student");

			// create the table Student
			//
			statement.executeUpdate(
				"create table Student" +
				"(id char(4)," +
			  	"name varchar(20), " +
			  	"primary key(id))");


			// insert some data
			//
			statement.executeUpdate(
				"insert into Student " +		// mind the space between
				"values ('S1', 'Smith')");		// 'Student' and 'values'

			statement.executeUpdate(
				"insert into Student " +
				"values ('S2', 'Adams')");

			statement.executeUpdate(
				"insert into Student " +
				"values ('S3', 'Blake')");

			// perform a query
			//
			ResultSet rs = statement.executeQuery("select * from student");
			while(rs.next())
			{
				String id = rs.getString(1);
				String name = rs.getString(2);
				System.out.println(id + ", " + name);
			}

			// To indicate that no exception has occurred
			System.out.println("Program terminates normally");
	  	}
	  	catch(Exception e)
	  	{
			e.printStackTrace();
		}
		finally
		{
			statement.close();
			connection.close();
		}
  	}
}
