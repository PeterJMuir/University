import java.sql.*;

public class ConnectToServerOnLatcs7
{
	public static void main(String [] args) throws Exception
	{
	  	// prepare to connect to MySQL database
	  	String databaseURL = "jdbc:mysql://latcs7.cs.latrobe.edu.au:3306/k2nguyen";

		String username = "k2nguyen";

		char [] pwd = System.console().readPassword("Password: ");
		String password = new String(pwd);

	  	Connection connection = null;
	  	Statement statement = null;

	  	try
	  	{
			// connect to the database
			connection = DriverManager.getConnection(databaseURL, username, password );

			// create a statement object
			statement = connection.createStatement();





			// perform a query
			//
			ResultSet rs = statement.executeQuery("select * from product");
			while(rs.next())
			{
				String id = rs.getString(1);
				String name = rs.getString(2);
				System.out.println(id + ", " + name);
			}

			rs = statement.executeQuery("show tables");
			System.out.println("\nshow table:");
			while(rs.next())
			{
				System.out.println(rs.getString(1));
			}

			rs = statement.executeQuery("describe product");
			System.out.println("\ndescribe product:");
			while(rs.next())
			{
				System.out.println(rs.getString(1) + " " + rs.getString(2));
			}

			// To indicate that no exception has occurred
			System.out.println("\n>> Program terminates normally");
	  	}
	  	catch(Exception e)
	  	{
			e.printStackTrace();
		}
		finally
		{
			statement.close();
			connection.close();
		}
  	}
}
