import java.sql.*;

public class InitializeStudentDB
{
	public static void main(String [] args) throws Exception
	{
	  	// prepare to connect to MySQL database
	  	String databaseURL = "jdbc:mysql://localhost:3306/StudentDB";
		String username = "";
		String password = "";
	  	Connection connection = null;
	  	Statement statement = null;

	  	try
	  	{
			// connect to the database
			connection = DriverManager.getConnection(databaseURL, username, password );

			// create a statement object
			statement = connection.createStatement();

			// execute statements to drop the tables if they exist
			statement.executeUpdate("drop table if exists Enrolment");
			statement.executeUpdate("drop table if exists Student");
			statement.executeUpdate("drop table if exists Subject");

			// create the tables
			//
			statement.executeUpdate(
				"create table Student" +
				"(id char(4)," +
			  	"name varchar(20), " +
			  	"primary key(id))");

			statement.executeUpdate(
				"create table Subject" +
				"(code char(4)," +
			  	"title varchar(20)," +
			  	"primary key(code))");

			statement.executeUpdate(
				"create table Enrolment" +
				"(id char(4)," +
			  	"code char(4)," +
			  	"mark int," +
			  	"primary key(id, code)," +
			  	"foreign key (id) references Student(id)," +
			  	"foreign key (code) references Subject(code))");

			// insert data into the tables
			//
			statement.executeUpdate(
				"insert into Student " +		// mind the space between
				"values ('S1', 'Smith')");		// 'Student' and 'values'

			statement.executeUpdate(
				"insert into Student " +
				"values ('S2', 'Adams')");

			statement.executeUpdate(
				"insert into Student " +
				"values ('S3', 'Blake')");

			statement.executeUpdate(
				"insert into Subject " +
				"values ('U1', 'Computing')");

			statement.executeUpdate(
				"insert into Subject " +
				"values ('U2', 'Maths')");

			statement.executeUpdate(
				"insert into Subject " +
				"values ('U3', 'Statistics')");


			statement.executeUpdate(
				"insert into Enrolment " +
				"values('S1', 'U1', 80)");

			statement.executeUpdate(
				"insert into Enrolment " +
				"values('S2', 'U1', 85)" );


			statement.executeUpdate(
				"insert into Enrolment " +
				"values('S3', 'U1', 75)");

			statement.executeUpdate(
				"insert into Enrolment " +
				"values('S1', 'U2', null)");

			statement.executeUpdate(
				"insert into Enrolment " +
				"values('S2', 'U2', null)");

			statement.executeUpdate(
				"insert into Enrolment " +
				"values('S3', 'U2', null)");

			statement.executeUpdate(
				"insert into Enrolment " +
				"values('S1', 'U3', null)");


			// update the mark 1 receives for u3
			//
			statement.executeUpdate(
				"update Enrolment " +
				"set mark = 90 " +
				"where id = 's1' and code = 'U3'");


			// delete student s3 from student table
			// Must delete s3 from table enrolment first
			//
			statement.executeUpdate("delete from enrolment where id = 's3'");
			statement.executeUpdate("delete from student where id = 's3'");

			ResultSet rs = statement.executeQuery("select * from student");
			while(rs.next())
			{
				String id = rs.getString(1);
				String name = rs.getString(2);
				System.out.println(id + ", " + name);
			}

			// To indicate that no exception has occurred
			System.out.println("Program terminates normally");
	  	}
	  	catch(Exception e)
	  	{
			// System.out.println(e);
			e.printStackTrace();
		}
		finally
		{
			statement.close();
			connection.close();
		}
  	}
}
