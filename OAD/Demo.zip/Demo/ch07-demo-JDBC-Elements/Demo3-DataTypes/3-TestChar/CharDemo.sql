-- char

Use DataTypesDemoDB;

drop table if exists TestChar;

create table TestChar
(	
	id int auto_increment,
	value char(4),				-- Must specify max size
	primary key (id)
);

insert into TestChar (value)
values('abc');

insert into TestChar (value)
values('abcd');

insert into TestChar (value)
values("abcd");

insert into TestChar (value)
values(null);				-- Java sees this as ?

-- insert into TestChar
-- values("abcde")		-- error, NULL is stored

select "Test data type char" as "";
select * from TestChar;

