import java.io.*;
import java.sql.*;

public class DataTypesDemo
{
	private static Connection connection = null;
	private static Statement statement = null;
	private static PreparedStatement ps = null;

	public static void main(String [] args) throws Exception
	{
		String databaseURL = "jdbc:mysql://localhost:3306/DataTypesDemoDB";
		String username = "";
		String password = "";

		connection = DriverManager.getConnection(databaseURL,username, password );
		statement = connection.createStatement();

		// testDouble();
		// testInt();
		// testChar();
		// testVarchar();
		// testBoolean();
		// testTimestamp();
		moreOnTimestamp();

		// Release resources
		statement.close();
		connection.close();
		System.out.println("\nTerminate normally");
	}

	static void testDouble() throws Exception
	{
		String query = "select * from testDouble";
		ResultSet rs = statement.executeQuery(query);
		System.out.println("\n" + query);
		display(rs);
	}

	static void testInt() throws Exception
	{
		String query = "select * from testInt";
		ResultSet rs = statement.executeQuery(query);
		System.out.println("\n" + query);
		display(rs);
	}

	static void testChar() throws Exception
	{
		String query = "select * from testChar";
		ResultSet rs = statement.executeQuery(query);
		System.out.println("\n" + query);
		display(rs);
	}

	static void testVarchar() throws Exception
	{
		String query = "select * from testVarchar";
		ResultSet rs = statement.executeQuery(query);
		System.out.println("\n" + query);
		display(rs);
	}

	static void testBoolean() throws Exception
	{
		String query = "select * from testBoolean";
		ResultSet rs = statement.executeQuery(query);
		System.out.println("\n" + query);
		display(rs);
	}

	static void testTimestamp() throws Exception
	{
		String query = "select * from testTimestamp";
		ResultSet rs = statement.executeQuery(query);
		System.out.println("\n" + query);
		display(rs);
	}

	static void moreOnTimestamp() throws Exception
	{
		// Get current timestamp, current date and current time (java.sql)
		// using GreorianCalendar class
		Timestamp currentTimestamp =
			new Timestamp(new java.util.GregorianCalendar().getTimeInMillis());
		System.out.println("\ncurentTimestamp: " + currentTimestamp);

		Date currentDate = new Date(currentTimestamp.getTime());
		System.out.println("\ncurentDate: " + currentDate);

		Time currentTime = new Time(currentTimestamp.getTime());
		System.out.println("\ncurentTime: " + currentTime);

		Timestamp aTimestamp = new Timestamp(
			new java.util.GregorianCalendar(2015, 1, 1, 12, 30, 0).getTimeInMillis());

		System.out.println("\naTimestamp: " + aTimestamp);


		// Returns the number of milliseconds since January 1, 1970, 00:00:00 GMT
		// represented by this Timestamp object.
		// We can use this to perform operations and comparisons
		//
		long milliSeconds = currentTimestamp.getTime();
		System.out.println("\nmilliSeconds: " + milliSeconds);

		// Set timestamp for sql tables from program
		// Timestamp ts = new Timestamp(2000, 1, 1, 12, 0, 0, 0);
		//
		String cmd = "insert into testTimestamp (value) values (?)";
		ps = connection.prepareStatement(cmd);

		ps.setTimestamp(1, currentTimestamp);
		ps.executeUpdate();
		ps.setTimestamp(1, aTimestamp);
		ps.executeUpdate();

		String query = "select * from testTimestamp";
		ResultSet rs = statement.executeQuery(query);
		display(rs);

		// DATE and TIME should be similar
	}

	static void display(ResultSet rs) throws Exception
	{
		ResultSetMetaData rsmd = rs.getMetaData();
		while (rs.next())
		{
			for (int i = 1; i <= rsmd.getColumnCount(); i++ )
			{
				switch (rsmd.getColumnType( i ))
				{
					case Types.CHAR:
					case Types.VARCHAR: System.out.print(rs.getString(i) );
							break;

					case Types.INTEGER: System.out.print(rs.getInt(i) );
							break;

					case Types.DOUBLE: System.out.print(rs.getDouble(i) );
							break;

					case Types.BIT: // Not Types.BOOLEAN
							System.out.print(rs.getBoolean(i) );
							break;

					case Types.DATE: System.out.print(rs.getDate(i) );
							break;

					case Types.TIME: System.out.print(rs.getTime(i) );
							break;

					case Types.TIMESTAMP: System.out.print(rs.getTimestamp(i) );
						break;

					default:System.out.println ("The type of the column is not recognized");
				} // case

				System.out.print("/");
			} // for

			System.out.println();
		} // while
	}
}


