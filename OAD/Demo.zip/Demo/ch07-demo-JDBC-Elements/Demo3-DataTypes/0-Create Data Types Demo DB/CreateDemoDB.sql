
--	Create a database 
Drop database if exists DataTypesDemoDB; 
Create database DataTypesDemoDB;
Use DataTypesDemoDB;

