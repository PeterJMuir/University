-- int

Use DataTypesDemoDB;

drop table if exists TestInt;

create table TestInt
(
	id int auto_increment,
	value int,
	primary key(id)
);

insert into TestInt (value)
values(123);

insert into TestInt (value)
values(1234567890);

insert into TestInt (value)
values(null);					-- Java sees null as 0

select "Test data type int" as "";
select * from TestInt;

