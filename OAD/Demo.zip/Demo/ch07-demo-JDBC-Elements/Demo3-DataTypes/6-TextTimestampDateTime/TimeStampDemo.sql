-- TIMESTAMP, Date, Time

Use DataTypesDemoDB;

drop table if exists TestTimestamp;

create table TestTimestamp
(
	id int auto_increment,
	value timestamp,
	primary key(id)
);

insert into testTimestamp (value)
values (now());

insert into testTimestamp (value)
values (timestamp '2000-01-01 12:00:00');

insert into testTimestamp (value)
values ('2000-01-01 12:00:00');

insert into testTimestamp (value)
values ('2000-01-01');

select * from testTimestamp;

select ">> Add date, add time" as "";
select value, addDate(value, 10), addTime(value, '10:00:00')
from testTimestamp;

select ">> Extract date and time" as "";
select value, date(value), time(value)
from testTimestamp;

select ">> Calculate difference in date" as "";
select
dateDiff('2000-01-10 00:00:00', '2000-01-01 12:00:00');

select ">> Calculate difference in time" as "";
select 
timeDiff(time('2000-01-01 00:00:00'), time('1900-01-01 5:30:30'));

select "" as "";
select 
timeDiff('2000-01-11 00:00:00', '2000-01-01 00:00:00');

select "" as "";
select 
timeDiff('2000-01-11 00:00:00', '2000-01-01 00:00:01');
