-- varchar

Use DataTypesDemoDB;

drop table if exists TestVarChar;

create table TestVarChar
(
	id int auto_increment,
	value varchar(100),		-- max size is about 64K bytes
	primary key (id)
);

insert into TestVarChar (value)
values('abc');

insert into TestVarChar (value)
values('abcd');

insert into TestVarChar (value)
values("This is supposed to be a very long line");

insert into TestVarChar (value)
values(concat(
	"This is supposed to be a very long line\n",
	"This is supposed to be a very long line")
);

insert into TestVarChar (value)
values(null);					-- Java sees this as ?

select "Test data type varchar" as "";
select * from TestVarChar;
