-- boolean

Use DataTypesDemoDB;

drop table if exists TestBoolean;

create table TestBoolean
(
	id int auto_increment,
	value boolean,
	primary key (id)
);	

insert into TestBoolean (value)
values(true);

insert into TestBoolean (value)
values(false);

insert into TestBoolean (value)
values(1);

insert into TestBoolean (value)
values(0);

insert into TestBoolean (value)
values(null);						-- Java reads this as false

select "Test data type boolean" as "";
select * from TestBoolean;
