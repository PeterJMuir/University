-- double data type

use DataTypesDemoDB;

drop table if exists TestDouble;

create table TestDouble
(
	id int auto_increment,	-- can only be of type int
	value double,				-- double(8,2)
	primary key(id)			-- required for auto_increment
);

insert into TestDouble (value)
values(123.1234);

insert into TestDouble (value)
values(1234567890.1234);

insert into TestDouble (value)
values(null);					-- Java sees null as 0.0

select "Test data type double" as "";
select * from TestDouble;

