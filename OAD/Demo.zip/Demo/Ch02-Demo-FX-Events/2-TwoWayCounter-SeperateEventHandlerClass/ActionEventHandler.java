import javafx.event.*;
import javafx.scene.control.*;

public class ActionEventHandler implements EventHandler<ActionEvent>
{
	private Button upBT;
	private Button downBT;
	private TextField countTF;
	private Integer count;

	public ActionEventHandler(Button upBT, Button downBT,TextField countTF, Integer count)
	{
		this.upBT = upBT;
		this.downBT = downBT;
		this.countTF = countTF;
		this.count = count;
	}

	@Override
	public void handle(ActionEvent e)
   {
		if (e.getSource() == upBT)
		{
			count++;
		}
		else
		{
			count--;
		}

		countTF.setText(Integer.toString(count));
	}
}