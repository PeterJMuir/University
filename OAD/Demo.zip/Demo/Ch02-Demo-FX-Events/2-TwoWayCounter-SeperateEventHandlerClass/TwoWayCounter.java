import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.event.*;

public class TwoWayCounter extends Application
{
	private Integer count = 0;
	private Button upBT;
	private Button downBT;
	private TextField countTF;

	public void start(Stage stage)
	{
		stage.setTitle("Two Way Counter");
		stage.sizeToScene();
		addContents(stage);
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Define controls and layout
		upBT = new Button("Count UP");
		downBT = new Button("Count DOWN");
		countTF = new TextField(Integer.toString(count));
		countTF.setPrefColumnCount(4);

		ActionEventHandler handler = new ActionEventHandler(upBT, downBT, countTF, count);
		upBT.setOnAction(handler);
		downBT.setOnAction(handler);

		Pane pane = new FlowPane();
		pane.getChildren().addAll(upBT, downBT, countTF);

		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}
}
