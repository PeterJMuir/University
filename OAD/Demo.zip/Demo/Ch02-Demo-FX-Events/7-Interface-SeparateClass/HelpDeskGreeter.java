public class HelpDeskGreeter implements Greeter
{
	public void greet(String name)
	{
		System.out.println("Hello " + name + "!");
	}

	public void ask()
	{
		System.out.println("How can we help you?");
	}
}