public class SeparateClassTester
{
	public static void main(String[] args)
	{
		Greeter greeter = new HelpDeskGreeter();
		greeter.greet("John");
		greeter.welcome();
		greeter.ask();

		Greeter.describe();
	}
}

/*
Hello John!
Welcome!
How can we help you?

Greeter interface has 3 instance methods:
greet (abstract), welcome and ask
*/
