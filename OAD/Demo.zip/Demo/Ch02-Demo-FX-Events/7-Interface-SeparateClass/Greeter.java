public interface Greeter
{
	public static final int INSTANCE_METHOD_COUNT = 3;

	public abstract void greet(String name);

	public default void welcome()
	{
		System.out.println("Welcome!");
	}

	public default void ask()
	{
		System.out.println("How are you?");
	}

	public static void describe()
	{
		System.out.println("\nGreeter interface has "
			+ INSTANCE_METHOD_COUNT + " instance methods:\n"
			+ "greet (abstract), welcome and ask");

	}
}