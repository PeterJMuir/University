public class LambdaExpressionTester
{
	public static void main(String[] args)
	{
		Greeter helpDeskGreeter = (name) ->
			{
				System.out.println("Hello " + name + "!");
			};

		helpDeskGreeter.greet("John");
		helpDeskGreeter.welcome();
		helpDeskGreeter.ask();

		Greeter.describe();
	}
}

/*
Hello John!
Welcome!
How are you?

Greeter interface has 3 instance methods:
greet (abstract), welcome and ask
*/
