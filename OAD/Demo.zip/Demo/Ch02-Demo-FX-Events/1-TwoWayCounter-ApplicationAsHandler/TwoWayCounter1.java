import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.event.*;

public class TwoWayCounter1 extends Application implements EventHandler<ActionEvent>
{
	private int count = 0;
	private Button upBT;
	private Button downBT;
	private TextField countTF;

	public void start(Stage stage)
	{
		stage.setTitle("Two Way Counter");
		stage.sizeToScene();
		addContents(stage);
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Define controls and layout
		upBT = new Button("Count UP");
		downBT = new Button("Count DOWN");
		countTF = new TextField(Integer.toString(count));
		countTF.setPrefColumnCount(4);

		upBT.setOnAction(this);
		downBT.setOnAction(this);

		Pane pane = new FlowPane();
		pane.getChildren().addAll(upBT, downBT, countTF);

		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}

	@Override
	public void handle(ActionEvent e)
   {
		if (e.getSource() == upBT)
		{
			count++;
		}
		else
		{
			count--;
		}

		countTF.setText(String.valueOf(count));
	}
}
