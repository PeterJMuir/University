import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

public class SampleFX extends Application
{
	private int count = 0;

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle("Sample");
		stage.sizeToScene();
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Define controls and layout
		Pane pane = new FlowPane();

		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}
}
