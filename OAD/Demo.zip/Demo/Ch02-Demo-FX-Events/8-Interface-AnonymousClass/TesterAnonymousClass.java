public class TesterAnonymousClass
{
	public static void main(String[] args)
	{
		Greeter helpDeskGreeter = new Greeter()
			{
				public void greet(String name)
				{
					System.out.println("Hello " + name + "!");
				}

				public void ask()
				{
					System.out.println("How can I help you?");
				}
			};

		helpDeskGreeter.greet("John");
		helpDeskGreeter.welcome();
		helpDeskGreeter.ask();

		Greeter.describe();
	}
}

/*
Hello John!
Welcome!
How can we help you?

Greeter interface has 3 instance methods:
greet (abstract), welcome and ask
*/
