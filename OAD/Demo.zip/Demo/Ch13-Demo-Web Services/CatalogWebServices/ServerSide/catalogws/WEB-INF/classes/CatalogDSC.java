import java.sql.*;
import java.util.*; // ArrayList and List

public class CatalogDSC
{

	//	TO SUPPORT CURRENT REST WEB SERVICE
	//

	// add a product
	public void add(Product product) throws Exception
	{
		String id = product.getId();
		String name = product.getName();
		double price = product.getPrice();
		boolean onSale = product.isOnSale();

		addProduct(id, name, price, onSale);
	}

	// find a product
	public Product find(String id) throws SQLException
	{
		return findOne(id);
	}

	//	find all products
	public List<Product> list()
	throws SQLException
	{
		connect();

		String queryString =
			"select * from product";

		preparedStatement = connection.prepareStatement(queryString);
		ResultSet rs = preparedStatement.executeQuery();

		ArrayList<Product> products = new ArrayList<Product>();

		while (rs.next())
		{
			String id = rs.getString(1);
			String name = rs.getString(2);
			double price = rs.getDouble(3);
			boolean onSale = rs.getBoolean(4);

			products.add(new Product(id, name, price, onSale));
		}

		return products;
	}

	// edit a product
	public void edit(Product product) throws SQLException
	{
		// for this version update the price only
		String id = product.getId();
		double price = product.getPrice();
		boolean onSale = product.isOnSale();
		try
		{
			updateProduct(id, price, onSale);
			// update price and onSale only
		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	// delete a product
	public void delete(Product product) throws SQLException
	{
		String id = product.getId();
		try
		{
			removeProduct(id);
		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	// DSC previously defined

	private Connection connection;
	private Statement statement;
	private PreparedStatement preparedStatement;

	public void connect() throws SQLException
	{
		String url = "jdbc:mysql://localhost:3306/CatalogDB";
		String user = "";
		String password = "";
		connection = DriverManager.getConnection(url, user, password);
		statement = connection.createStatement();
	}

	public void disconnect() throws SQLException
	{
		if(preparedStatement != null) preparedStatement.close();
		if(statement != null) statement.close();
		if(connection != null) connection.close();
	}

	// Retrieve a Product by id
	//	Returns null if the product does not exist
	//	(The lab will elaborate on data operation methods such as this)
	//
	public Product findOne(String id) throws SQLException
	{
		connect();

		String queryString = "select * from Product where id = ?";
		preparedStatement = connection.prepareStatement(queryString);
		preparedStatement.setString(1, id);
		ResultSet rs = preparedStatement.executeQuery();

		Product product = null;

		if(rs.next())	// Product exists
		{
			// String id = rs.getString(1);
			String name = rs.getString(2);
			double price = rs.getDouble(3);
			boolean onSale = rs.getBoolean(4);
			product = new Product(id, name, price, onSale);
		}

		return product;

	}	// end of findOne

	// Add a product
	public void addProduct(String id, String name, double price, boolean onSale) throws Exception
	{
		Product product = findOne(id);
		boolean pre = (product == null);
		if(! pre)
		{
			String msg = "Product id " + id + " is not new!";
			System.out.println("\nERROR: " + msg);
			throw new Exception(msg);
		}

		// post: add product

		connect();

		String insertString = "insert into Product values(?, ?, ?, ?)";
		preparedStatement = connection.prepareStatement(insertString);
		preparedStatement.setString(1, id);
		preparedStatement.setString(2, name);
		preparedStatement.setDouble(3, price);
		preparedStatement.setBoolean(4, onSale);
		preparedStatement.executeUpdate();

		// release resource
		disconnect();

	}	// addProduct


	//	We would have this method if it is part of the functional requirements
	public Product searchProduct(String id) throws SQLException
	{
		return findOne(id);
	}

	//	Update the price of a product
	public void updateProductPrice(String id, double price) throws Exception
	{
		Product product = findOne(id);
		boolean pre = (product != null);
		if(! pre)
		{
			String msg = "Product does not exist!";
			System.out.println("\nERROR: " + msg);
			throw new Exception(msg);
		}

		// post: update product's price

		connect();

		String updateString =
			"update Product " +
			"set price = ? " +
			"where id = ? ";

		preparedStatement = connection.prepareStatement(updateString);
		preparedStatement.setDouble(1, price);
		preparedStatement.setString(2, id);

		preparedStatement.executeUpdate();
	}

	//	Update the price of a product
	public void updateProduct(String id, double price, boolean onSale) throws Exception
	{
		Product product = findOne(id);
		boolean pre = (product != null);
		if(! pre)
		{
			String msg = "Product does not exist!";
			System.out.println("\nERROR: " + msg);
			throw new Exception(msg);
		}

		// post: update product's price

		connect();

		String updateString =
			"update Product " +
			"set price = ?, " +
			"    onSale = ? " +
			"where id = ? ";

		preparedStatement = connection.prepareStatement(updateString);
		preparedStatement.setDouble(1, price);
		preparedStatement.setBoolean(2, onSale);
		preparedStatement.setString(3, id);

		preparedStatement.executeUpdate();

	}// update product price and on sale


	//	Remove a product
	public void removeProduct(String id) throws Exception
	{
		Product product = findOne(id);
		boolean pre = (product != null);
		if(! pre)
		{
			String msg= ">>>ERROR: Product does not exist!";
			System.out.println(msg);
			throw new Exception(msg);
		}

		connect();
		String deleteStatement =
			"delete from product " +
			"where id = ? ";
		preparedStatement = connection.prepareStatement(deleteStatement);
		preparedStatement.setString(1, id);
		preparedStatement.executeUpdate();

		disconnect();
	}

	// We do not need this method when we use Swing and JTable
	//	because we can use the JTable to directly filter the rows
	//	But we should have this method in anticipation of using
	// this class with other kinds of user interface
	//
	public ArrayList<Product> getProductsInPriceRange(double lower, double upper)
	throws SQLException
	{
		connect();

		String queryString =
			"select * from product where ? <= price and price <= ?";

		preparedStatement = connection.prepareStatement(queryString);
		preparedStatement.setDouble(1, lower);
		preparedStatement.setDouble(2, upper);
		ResultSet rs = preparedStatement.executeQuery();

		ArrayList<Product> products = new ArrayList<Product>();

		while (rs.next())
		{
			String id = rs.getString(1);
			String name = rs.getString(2);
			double price = rs.getDouble(3);
			boolean onSale = rs.getBoolean(4);

			products.add(new Product(id, name, price, onSale));
		}

		return products;
	}



	/***************************************************************
								Tests
	***************************************************************/
	public static void main(String [] args) throws Exception
	{
		System.out.println("find p20 " + (new CatalogDSC()).findOne("p20"));
	}

	public static void initialTests() throws Exception
	{
		// run CreateCatalogDB.bat first to initialize the database
		// inspect table product to verify the results
		//
		java.lang.Runtime rt = java.lang.Runtime.getRuntime();
		java.lang.Process process = rt.exec("CreateCatalogDB.bat");

		CatalogDSC catalogDSC = new CatalogDSC();

		System.out.println("find p20 " + catalogDSC.findOne("p20"));
		System.out.println("find p100 " + catalogDSC.findOne("p100"));

		catalogDSC.addProduct("p100", "TV", 1000.50, true);
		System.out.println(catalogDSC.findOne("p100") + "\n");

		Product p = catalogDSC.searchProduct("p10");
		System.out.println("Product p10: " + p + "\n");

		catalogDSC.updateProductPrice("p100", 2000.50);
		p = catalogDSC.searchProduct("p100");
		System.out.println("Product p100: "  + p + "\n");

		catalogDSC.removeProduct("p100");
		p = catalogDSC.searchProduct("p100");
		System.out.println("Product p100: "  + p + "\n");

		ArrayList<Product>  list = catalogDSC.getProductsInPriceRange(0, 35);
		System.out.println(list+ "\n");
	}

}
