import java.sql.*;
import java.util.ArrayList;

public class CatalogDSCTester
{
	public static void main(String [] args) throws Exception
	{
		System.out.println("find p20 " + CatalogDSC.findOne("p20"));
		CatalogDSC.addProduct("p200", "Lights", 50.50, false);

	}

	public static void initialTests() throws Exception
	{
		// run CreateCatalogDB.bat first to initialize the database
		// inspect table product to verify the results
		//
		java.lang.Runtime rt = java.lang.Runtime.getRuntime();
		java.lang.Process process = rt.exec("CreateCatalogDB.bat");

		Object [] columnNames = CatalogDSC.getColumnNames();
		for (int i = 0; i < columnNames.length; i++)
		{
			System.out.println(columnNames[i]);
		}

		System.out.println("find p20 " + CatalogDSC.findOne("p20"));
		System.out.println("find p100 " + CatalogDSC.findOne("p100"));

		CatalogDSC.addProduct("p100", "TV", 1000.50, true);
		System.out.println(CatalogDSC.findOne("p100") + "\n");

		Product p = CatalogDSC.searchProduct("p10");
		System.out.println("Product p10: " + p + "\n");

		CatalogDSC.updateProductPrice("p100", 2000.50);
		p = CatalogDSC.searchProduct("p100");
		System.out.println("Product p100: "  + p + "\n");

		CatalogDSC.removeProduct("p100");
		p = CatalogDSC.searchProduct("p100");
		System.out.println("Product p100: "  + p + "\n");

		ArrayList<Product>  list = CatalogDSC.getProductsInPriceRange(0, 35);
		System.out.println(list+ "\n");
	}

}
