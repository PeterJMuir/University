import java.sql.*;
import java.util.*; // ArrayList and List

public class CatalogDSC
{

	//	TO SUPPORT CURRENT REST WEB SERVICE
	//

	// add a product
	public static void add(Product product) throws Exception
	{
		String id = product.getId();
		String name = product.getName();
		double price = product.getPrice();
		boolean onSale = product.isOnSale();

		addProduct(id, name, price, onSale);
	}

	// find a product
	public static Product find(String id) throws SQLException
	{
		return findOne(id);
	}

	//	find all products
	public static List<Product> list()
	throws SQLException
	{
		connect();

		String queryString =
			"select * from product";

		preparedStatement = connection.prepareStatement(queryString);
		ResultSet rs = preparedStatement.executeQuery();

		ArrayList<Product> products = new ArrayList<Product>();

		while (rs.next())
		{
			String id = rs.getString(1);
			String name = rs.getString(2);
			double price = rs.getDouble(3);
			boolean onSale = rs.getBoolean(4);

			products.add(new Product(id, name, price, onSale));
		}

		return products;
	}

	// edit a product
	public static void edit(Product product) throws SQLException
	{
		// for this version update the price only
		String id = product.getId();
		double price = product.getPrice();
		try
		{
			updateProductPrice(id, price);
		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	// delete a product
	public static void delete(Product product) throws SQLException
	{
		String id = product.getId();
		try
		{
			removeProduct(id);
		}
		catch(Exception e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	// DSC previously defined

	private static Connection connection;
	private static Statement statement;
	private static PreparedStatement preparedStatement;

	public static void connect() throws SQLException
	{
		String url = "jdbc:mysql://localhost:3306/CatalogDB";
		String user = "";
		String password = "";
		connection = DriverManager.getConnection(url, user, password);
		statement = connection.createStatement();
	}

	public static void disconnect() throws SQLException
	{
		if(preparedStatement != null) preparedStatement.close();
		if(statement != null) statement.close();
		if(connection != null) connection.close();
	}

	// Retrieve a Product by id
	//	Returns null if the product does not exist
	//	(The lab will elaborate on data operation methods such as this)
	//
	public static Product findOne(String id) throws SQLException
	{
		connect();

		String queryString = "select * from Product where id = ?";
		preparedStatement = connection.prepareStatement(queryString);
		preparedStatement.setString(1, id);
		ResultSet rs = preparedStatement.executeQuery();

		Product product = null;

		if(rs.next())	// Product exists
		{
			// String id = rs.getString(1);
			String name = rs.getString(2);
			double price = rs.getDouble(3);
			boolean onSale = rs.getBoolean(4);
			product = new Product(id, name, price, onSale);
		}

		return product;

	}	// end of findOne

	// Add a product
	public static void addProduct(String id, String name, double price, boolean onSale) throws Exception
	{
		Product product = findOne(id);
		boolean pre = (product == null);
		if(! pre)
		{
			String msg = "Product id " + id + " is not new!";
			System.out.println("\nERROR: " + msg);
			throw new Exception(msg);
		}

		// post: add product

		connect();

		String insertString = "insert into Product values(?, ?, ?, ?)";
		preparedStatement = connection.prepareStatement(insertString);
		preparedStatement.setString(1, id);
		preparedStatement.setString(2, name);
		preparedStatement.setDouble(3, price);
		preparedStatement.setBoolean(4, onSale);
		preparedStatement.executeUpdate();

		// release resource
		disconnect();

	}	// addProduct


	//	We would have this method if it is part of the functional requirements
	public static Product searchProduct(String id) throws SQLException
	{
		return findOne(id);
	}

	//	Update the price of a product
	public static void updateProductPrice(String id, double price) throws Exception
	{
		Product product = findOne(id);
		boolean pre = (product != null);
		if(! pre)
		{
			String msg = "Product does not exist!";
			System.out.println("\nERROR: " + msg);
			throw new Exception(msg);
		}

		// post: update product's price

		connect();

		String updateString =
			"update Product " +
			"set price = ? " +
			"where id = ? ";

		preparedStatement = connection.prepareStatement(updateString);
		preparedStatement.setDouble(1, price);
		preparedStatement.setString(2, id);

		preparedStatement.executeUpdate();
	}


	//	Remove a product
	public static void removeProduct(String id) throws Exception
	{
		Product product = findOne(id);
		boolean pre = (product != null);
		if(! pre)
		{
			String msg= ">>>ERROR: Product does not exist!";
			System.out.println(msg);
			throw new Exception(msg);
		}

		connect();
		String deleteStatement =
			"delete from product " +
			"where id = ? ";
		preparedStatement = connection.prepareStatement(deleteStatement);
		preparedStatement.setString(1, id);
		preparedStatement.executeUpdate();

		disconnect();
	}

	// We do not need this method when we use Swing and JTable
	//	because we can use the JTable to directly filter the rows
	//	But we should have this method in anticipation of using
	// this class with other kinds of user interface
	//
	public static ArrayList<Product> getProductsInPriceRange(double lower, double upper)
	throws SQLException
	{
		connect();

		String queryString =
			"select * from product where ? <= price and price <= ?";

		preparedStatement = connection.prepareStatement(queryString);
		preparedStatement.setDouble(1, lower);
		preparedStatement.setDouble(2, upper);
		ResultSet rs = preparedStatement.executeQuery();

		ArrayList<Product> products = new ArrayList<Product>();

		while (rs.next())
		{
			String id = rs.getString(1);
			String name = rs.getString(2);
			double price = rs.getDouble(3);
			boolean onSale = rs.getBoolean(4);

			products.add(new Product(id, name, price, onSale));
		}

		return products;
	}

	/*
	The next two methods are to support the construction of the table
	model of JTable. Strictly speaking, they are not part of the functional
	requirements.
	*/

	// Return the array of column names
	//
	public static Object[] getColumnNames()
	{
		return Product.getColumnNames();
	}

	// Return 2-dimensional array of data
	// Each row represents a Product
	//
	public static Object[][] getData() throws SQLException
	{
		connect();

		String queryString = "select * from Product";
		ResultSet rs = statement.executeQuery(queryString);

		// Get column count and row count
		int columnCount = Product.getColumnNames().length;
		int rowCount = rs.last()? rs.getRow(): 0;
		rs.beforeFirst();

		// Construct the data to return
		Object [][] data = new Object [rowCount][columnCount];

		for(int row = 0; row < rowCount; row++)
		{
			// fetch the next row
			rs.next();

			// retrieve data for each column
			ResultSetMetaData rsmd = rs.getMetaData();
			for (int col = 1; col <= columnCount; col++ )
			{
				switch (rsmd.getColumnType( col ))
				{
					case Types.CHAR:
					case Types.VARCHAR:
						data[row][col-1] = rs.getString(col);
						System.out.println(rs.getString(col));
						break;
					case Types.INTEGER:
					data[row][col-1] = rs.getInt(col);
						System.out.println(rs.getInt(col));
						break;
					case Types.DOUBLE:
						data[row][col-1] = rs.getDouble(col);
						System.out.println(rs.getDouble(col));
						break;
					case Types.BIT:
						data[row][col-1] = rs.getBoolean(col);
						System.out.println(rs.getBoolean(col));
						break;
					case Types.TIMESTAMP:
						data[row][col-1] = rs.getTimestamp(col);
						System.out.println(rs.getTimestamp(col));
						break;

					default:
						System.out.println("What!: " + rs.getString(col));

				}// switch
			}
		}

		disconnect();
		return data;

	} // end of getData


	/***************************************************************
								Tests
	***************************************************************/
	public static void main(String [] args) throws Exception
	{
		System.out.println("find p20 " + CatalogDSC.findOne("p20"));
	}

	public static void initialTests() throws Exception
	{
		// run CreateCatalogDB.bat first to initialize the database
		// inspect table product to verify the results
		//
		java.lang.Runtime rt = java.lang.Runtime.getRuntime();
		java.lang.Process process = rt.exec("CreateCatalogDB.bat");

		Object [] columnNames = CatalogDSC.getColumnNames();
		for (int i = 0; i < columnNames.length; i++)
		{
			System.out.println(columnNames[i]);
		}

		System.out.println("find p20 " + CatalogDSC.findOne("p20"));
		System.out.println("find p100 " + CatalogDSC.findOne("p100"));

		CatalogDSC.addProduct("p100", "TV", 1000.50, true);
		System.out.println(CatalogDSC.findOne("p100") + "\n");

		Product p = CatalogDSC.searchProduct("p10");
		System.out.println("Product p10: " + p + "\n");

		CatalogDSC.updateProductPrice("p100", 2000.50);
		p = CatalogDSC.searchProduct("p100");
		System.out.println("Product p100: "  + p + "\n");

		CatalogDSC.removeProduct("p100");
		p = CatalogDSC.searchProduct("p100");
		System.out.println("Product p100: "  + p + "\n");

		ArrayList<Product>  list = CatalogDSC.getProductsInPriceRange(0, 35);
		System.out.println(list+ "\n");
	}

}
