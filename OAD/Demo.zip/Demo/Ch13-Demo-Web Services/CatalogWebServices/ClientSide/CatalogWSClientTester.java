// Some quick tests
//
public class CatalogWSClientTester
{
	public static void main(String[] args) throws Exception
  	{
		CatalogWSClient catalogWSClient = new CatalogWSClient();

		// Test 1
		catalogWSClient.add("r100", "Lights", 100, false);

		// Test 2
		// catalogWSClient.edit("r100", "Light", 10000, true);
		// catalogWSClient.edit("r200", "Lights", 200, true);

		// Test 3
		// catalogWSClient.delete("r100");

		//	Test 4
		// String s = catalogWSClient.get("p20");
		// System.out.println("\n>>> product received in JSON:\n" + s);

		//	Test 5
		// String s = catalogWSClient.getAll();
		// System.out.println("\nProduct list as JSON:\n" + s);
    }
}