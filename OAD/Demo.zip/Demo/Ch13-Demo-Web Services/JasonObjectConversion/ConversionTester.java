// Requires gson-2.2.4.jar. Put it in the lib subdir of current directory
//	Compile:	javac -cp .;lib\* *.java
// Run:		java -cp .;lib\*. ConversionTester

import com.google.gson.Gson;
import java.util.*;
import java.lang.reflect.*;	// Type, etc.
import com.google.gson.*;
import com.google.gson.reflect.*;

public class ConversionTester
{
	public static void main(String [] args)
	{
		Gson g = new Gson();

		//	Convert a Product instance to json
		Product p1 = new Product("p10", "chair", 10.99, true);
		String s = g.toJson(p1);
		System.out.println("product in JSON: " + s + "\n");

		//	Convert Json string back to Product
		Product p2 = g.fromJson(s, Product.class);
		System.out.println(p2 + "\n");

	//	Convert a list of objects to json
		//
		ArrayList<Product> products = new ArrayList<Product>();
		products.add(new Product("p10", "table", 10.99, false));
		products.add(new Product("p20", "chair", 20.99, true));
		products.add(new Product("p30", "desk", 30.99, false));

		Type listType = new TypeToken<List<Product>>() {}.getType();
		s = g.toJson(products, listType);

		System.out.println("product list in JSON: " + s + "\n");

		//	Convert json string back to the list
		ArrayList<String> products2 = g.fromJson(s, listType);
		System.out.println(products2);
	}
}

/*
Output:
------

product in JSON: {"MISSING_PRICE":-1,"id":"p10","name":"chair","price":10.99,"onSale":true}


Product[id: p10, name: chair, price: 10.99, onSale: true]

product list in JSON: [{"MISSING_PRICE":-1,"id":"p10","name":"table","price":10.99,"onSale":false},{
"MISSING_PRICE":-1,"id":"p20","name":"chair","price":20.99,"onSale":true},{"MISSING_PRICE":-1,"id":" p30","name":"desk","price":30.99,"onSale":false}]

[Product[id: p10, name: table, price: 10.99, onSale: false], Product[id: p20, name: chair, price: 20.99, onSale: true], Product[id: p30, name: desk, price: 30.99, onSale: false]]

*/