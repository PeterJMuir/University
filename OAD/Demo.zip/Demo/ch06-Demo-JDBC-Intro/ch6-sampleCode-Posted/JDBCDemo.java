import java.io.*;
import java.sql.*;

public class JDBCDemo
{
	public static void main(String [] args) throws Exception
	{
		// prepare to connect to MySQL database
		String databaseURL = "jdbc:mysql://localhost:3306/CatalogDB";
		String username = "";
		String password = "";
		Connection connection = null;
		Statement statement = null;

	 	try
		{
			// load the JDBC driver
			Class.forName("com.mysql.jdbc.Driver");

			// connect to the database
			connection = DriverManager.getConnection(databaseURL,username, password );

			// create a statement object
			statement = connection.createStatement();

			// perform a query and get a result set
			ResultSet rs = statement.executeQuery(
				"select * from product");

			// display the query result
			//
			// Initially, the row-pointer (aka cursor) is placed before the first row
			// Statement rs.next() will move the row-pointer to the next row
			// This statement returns false when we move past the last record

			while (rs.next())
			{
				String id = rs.getString(1);
				String name = rs.getString(2);
				Double price = rs.getDouble(3);
				boolean onSale = rs.getBoolean(4);

				System.out.println("id: " + id + ", name: " + name
					+ ", price: " + price + ", onSale: " + onSale);
			}

			// indicate that no exception has been thrown
			System.out.println(">>> Program terminates normally");
  	}
		catch(Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
	}
}