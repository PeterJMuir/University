
var app = angular.module('myApp', []);

app.controller('myCtrl', function($scope)
	{
    	$scope.surName = "Smith";

    	$scope.fullName = function()
    		{
    			return $scope.firstName + " " + $scope.surName;
    		};
	});
