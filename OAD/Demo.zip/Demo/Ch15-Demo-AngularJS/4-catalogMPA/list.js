
var app = angular.module("myApp", []);

app.controller("myController", function($scope, $http)
	{

		$scope.products = null;


			var connection = $http(
			{
				method: "get",
				url: "http://localhost:8080/catalogws/api/product"
			})

			.then(function(response)
			{
				$scope.products = response.data;
				// alert("Successfully get all the products");
			})

			.catch(function(response)
			{
				$scope.message("Message for getAllproduct: Error - status: " + response.status);
				// alert("Error in getting all the products");
			})


	});
	//end controller