var app = angular.module("myApp", []);

app.controller("myController", function($scope, $http){


	$scope.delete = function(){

		$http({
			method: "delete",
			url: "http://localhost:8080/catalogws/api/product?id=" + $scope.id
		})

		.then(function(response){

			$scope.message = "Message for Delete Product: Success - status: "
				+ response.status;
		})
		.catch(function(response){

			$scope.message = "Message for Delete Product: Error - status: "
				+ response.status;

		})
		.finally(function(response){
			// display message?
			// No convenient place for this

		});
	}
	// end delete


});
//end controller