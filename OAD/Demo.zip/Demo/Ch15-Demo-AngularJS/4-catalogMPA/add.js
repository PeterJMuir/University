
var app = angular.module("myApp", []);

app.controller("myController", function($scope, $http){

	$scope.add = function() {

		var connection = $http(
			{
				method: "post",
				url: "http://localhost:8080/catalogws/api/product",
				data:
					{
						"MISSING_PRICE":-1,
						"id": $scope.id,
						"name": $scope.name,
						"price": $scope.price,
						"onSale": $scope.onSale == null? "false": "true"
					}
			})

		.then(function(response)
			{
				$scope.message = "Message for Add Product: Success - status: " + response.status;
				// alert("response data: " + JSON.stringify(response.data));
			})

		.catch(function(response)
			{
				$scope.message = "Message for Add Product: Error - status: " + response.status
					+ response.data;
			})

		.finally (function(config)
			{

			});

	};

});
//end controller