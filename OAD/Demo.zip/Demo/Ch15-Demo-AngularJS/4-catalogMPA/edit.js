var app = angular.module("myApp", []);

app.controller("myController", function($scope, $http){

	$scope.edit = function() {

		var connection = $http(
			{
				method: "put",
				url: "http://localhost:8080/catalogws/api/product",
				data:
					{
						"MISSING_PRICE":-1,
						"id": $scope.id,
						"name": $scope.name,
						"price": $scope.price,
						"onSale": $scope.onSale == null? "false" : "true"
					}
			})

		.then(function(response)
		{
			$scope.message = "Message for Edit Product: Success - status: " + response.status;
		})

		.catch(function(response)
			{
				$scope.message = "Message for Edit Product: Error - status: " + response.status
					+ response.data;
			})

		.finally (function(config)
			{
				// document.getElementById("editMessageHolder").innerHTML=$scope.message;
			});
	};
	// end submit edit


});
//end controller