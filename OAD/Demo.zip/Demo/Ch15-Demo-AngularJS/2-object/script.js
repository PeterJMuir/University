
var app = angular.module('myApp', []);

app.controller('myController', function($scope)
	{
    	$scope.person = person;
	});

// define an object called person
//
var person = new Object();
person.firstName = "John";
person.surName = "Smith";

person.fullName = function()
	{
		return person.firstName + " " + person.surName;
	};
