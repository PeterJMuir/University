
var app = angular.module('myApp', []);

app.controller('myController', function($scope)
	{
    	$scope.persons = persons;
	});

// define an array of Persons
//
var persons =
	[
		{firstName: "John", surName: "Smith"},
		{firstName: "Jane", surName: "Doe"},
		{firstName: "Mickey", surName: "Mouse"},
		{firstName: "Donald", surName: "Duck"}
	];