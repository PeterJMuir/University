import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class HelloWorldServlet extends HttpServlet
{
public void doGet(HttpServletRequest request,  HttpServletResponse response) throws ServletException, IOException
	{
		// Tell client that we are going to send back a HTML page
		response.setContentType("text/html");

	 	 // Get the output channel
	  	PrintWriter out = response.getWriter();

	  	// Send the page
      		out.println(
			"<HTML>\n" +
			"<HEAD> </HEAD>\n" +
			"<BODY style='color:blue'>\n" +
			"<H1> Hello World, <br/>" +
			"Http Servlet speaking! </H2>\n" +
			"</BODY>\n" +
			"</HTML>");
  	}
}
