import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public interface WebEvent
{
	public abstract void respond(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException;
}