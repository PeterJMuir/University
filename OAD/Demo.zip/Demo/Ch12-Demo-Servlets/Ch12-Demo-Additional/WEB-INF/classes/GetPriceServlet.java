import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class GetPriceServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request,  HttpServletResponse response) throws ServletException, IOException
	{
		// Extract the parameters id and price
		String id = request.getParameter("id");
		String price = request.getParameter("price");

		// take action to update the price of the product ...

		// Send back the HTML page
		//
		// Tell client that we are going to send back a HTML page
		response.setContentType("text/html");

	 	 // Get the output channel
	  	PrintWriter out = response.getWriter();

	  	// Send the page
      	out.println(
			"<HTML>\n" +
			"<HEAD> </HEAD>" +
			"<BODY style='color:blue'>" +

			"id: " + id + "</br>" +

			"price: " + price + "</br>" +

			"</BODY>" +
			"</HTML>");
  	}
}