import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class FrontServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response)
   	throws ServletException, IOException
   {
		try
		{
			// identify the web event
			String event = null;
			Enumeration parameters = request.getParameterNames();
			while (parameters.hasMoreElements())
			{
				String name = (String) parameters.nextElement();
				System.out.println(">> name: " + name);

				if(name.indexOf("event") != -1)	// event found
				{
					event = name.substring("event:".length());
					break;
				}
			}
			System.out.println(">> DEBUG INFO - event: " + event);


			// delegate response task to event handler
			String className = event + "Event";
			System.out.println(">> DEBUG INFO - className: " + className);
			WebEvent responder = (WebEvent) Class.forName(className).newInstance();
			responder.respond(request, response);
		}
		catch(Exception e)	// the only place where we send back error message
		{
				String message = " ERROR " + e.getMessage();
				e.printStackTrace();
				response.getWriter().println("<h2 style='color:red'>" + message + "</h2>");
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{
		doGet(request, response);
	}
}

