import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;


/*
Event: 		Calculate
Input:		cost? (double), salvage? (double), years? (int)
Pre: 			For simplicity we check the format only
Action: 		NONE
Output: 		cost?, salvage?, years?
				depreciation! = calculated by formula
Page Data:	as for output	(when the page has only one block, e.g. HTML div)
Page Event: Calculate
*/

public class CalculateEvent implements WebEvent
{
	public void respond(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// Get inputs
		double cost = Double.parseDouble(request.getParameter("cost").trim());
		double salvaged = Double.parseDouble(request.getParameter("salvaged").trim());
		int years = Integer.parseInt(request.getParameter("years").trim());

		System.out.println(">>> DEBUG INFO - From Calulate respond");

		// For simplicity, we do not explicitly check any preconditions
		//	So long as the paramters are of the right type, no exception
		// will be thrown at this point

		// No server side actions

		// Calculate output 'depreciation'
		double depreciation = (cost - salvaged) / years;
			// If year is 0, an exception will be thrown
		System.out.println(">>> DEBUG INFO - depreciation: " + depreciation);

		// construct return web page
		// write HTML heading
		StringBuffer page = new StringBuffer();
		page.append("<html>");
		page.append("<head></head>");
		page.append("<body>");
		page.append("<h2> Depreciation Calculator</h2>");

		// begin HTML form
		page.append("<form action='FrontServlet' method='post'/>");

		page.append("	Enter the cost: <input type='text' name ='cost' value='"
			+ cost + "' /> </br/>");

		page.append("	Enter the salvage value: <input type='text' name ='salvaged' value='"
			+ salvaged + "' /> </br/>");

		page.append("	Enter the years of expectancy: <input type='text' name ='years' value='" + years + "' /> </br/>");

		page.append("  <input type='submit' name='event:Calculate' value='CALCULATE DEPRECIATION'> <br/>");

		page.append("	Yearly depreciation: <input type='text' name ='depreciation' value='"
			+ depreciation + "' /> </br/>");

		page.append("</form>");

		// end HTML page
		page.append("</body></html>");

		// send HTML page
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println(page);
	}
}


