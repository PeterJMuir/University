import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class GetParametersServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request,  HttpServletResponse response) throws ServletException, IOException
	{
		// Extract parameter values
		//
		// text field
		String text1 = request.getParameter("text1");

		// password
		String password1 = request.getParameter("password1");

		// checkbox cb1
		String cb1 = request.getParameter("cb1");

		// multiple checkboxes with the same name
		String [] cb23 = request.getParameterValues("cb23");

		// radio buttons
		String rd1 = request.getParameter("rd1");

		// text area
		String ta1 = request.getParameter("ta1");

		// single option select
		String select1 = request.getParameter("select1");

		// multiple option select
		String [] select2 = request.getParameterValues("select2");

		// hidden field
		String hf1 = request.getParameter("hf1");


		// send back html page with parameter values
		//
		response.setContentType("text/html");
	  	PrintWriter out = response.getWriter();

		out.println(
			"<HTML>" +
			"<HEAD> </HEAD>" +
			"<BODY style='color:blue'>" +

			"TEXT FIELD text1: " + text1 + "</br>" +

			"PASSWORD FIELD password1: " + password1 + "</br>" +

			"CHECKBOX cb1: " + cb1 + "</br>" +

			"CHECKBOXES OF SAME NAME cb23: " +
				(cb23==null? null:java.util.Arrays.asList(cb23)) + "</br>" +

			"RADIO BUTTONS rd1: " + rd1 + "</br>" +

			"TEXT AREA ta1: " + ta1 + "</br>" +
			"<pre>" + ta1 + "</pre></br>" +

			"SINGLE OPTION SELECT select1: " + select1 + "</br>" +

			"MULTIPLE OPTION SELECT select2: " +
				(select2==null? null:java.util.Arrays.asList(select2)) + "</br>" +

			"HIDDEN FIELD hf1: " + hf1 + "</br>" +

			"</BODY>" +
			"</HTML>");
  	}
}
