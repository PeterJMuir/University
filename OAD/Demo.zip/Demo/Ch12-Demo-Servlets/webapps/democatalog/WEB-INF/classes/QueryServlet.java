import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.util.*;
import java.sql.*; // SQLException

public class QueryServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		//	Access resource on the server side
		// Perform a query
		CatalogDSC catalogDSC = new CatalogDSC();
		List<Product> products = null;

		try
		{
			products = catalogDSC.getAllProducts();
		}
		catch(SQLException e)
		{
			throw new RuntimeException(e.getMessage());
		}

		// Send the query result back to client
		//

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// Send the page
		String rows = "";
		for(Product p: products)
		{
			rows = rows + "<tr><td>" + p.getId() + ", " + p.getName() + "</td></tr>";
		}

		out.println(
			"<HTML>\n" +
			"<HEAD> </HEAD>\n" +
			"<BODY>\n" +
			"<H2> Query Result </H2>\n" +

			"<table>" +
			rows +
			"</table>" +

			"</BODY>\n" +
			"</HTML>");
	}
}