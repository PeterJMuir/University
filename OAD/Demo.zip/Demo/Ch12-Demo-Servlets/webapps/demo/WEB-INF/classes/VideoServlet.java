import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

import java.io.*;	// PrintWriter

public class VideoServlet extends HttpServlet
{

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		//	Set response type
		response.setContentType("video/mp4");

		//	Get audio file and read it into a byte array
		String pathToWeb = getServletContext().getRealPath(File.separator);
		String filename = pathToWeb + "muppet.mp4";
		FileInputStream fis = new FileInputStream(new File(filename));
		int size = fis.available();
		System.out.println(">>> size: " + size);
		byte [] bytes = new byte[size];
		for(int i = 0; i < size; i++)
		{
			bytes[i] = (byte) fis.read();
		}

		fis.close();

		// Write the byte array to output stream
		OutputStream out = response.getOutputStream();
		for(int i = 0; i < size; i++)
		{
			out.write(bytes[i]);
		}

		out.close();
	}
}