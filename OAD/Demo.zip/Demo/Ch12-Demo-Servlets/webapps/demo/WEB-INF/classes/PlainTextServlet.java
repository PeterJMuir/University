import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class PlainTextServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// Tell client that we will send a HTML page
		response.setContentType("text/plain");

		// Get the output channel
		PrintWriter out = response.getWriter();

		// Send the page
		out.println("Hello World, Servlet speaking through plain text!");
	}
}