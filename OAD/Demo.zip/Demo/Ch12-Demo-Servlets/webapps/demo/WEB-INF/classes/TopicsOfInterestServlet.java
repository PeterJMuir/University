import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class TopicsOfInterestServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request,
	HttpServletResponse response) throws ServletException, IOException
	{
		// get topics entered by user
		String topic1 = request.getParameter("topic1");
		String topic2 = request.getParameter("topic2");
		String topic3 = request.getParameter("topic3");

		// send client the page
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String page =
			"<html> <head> </head>" +
			"<body>" +
				"<h1> Your topics of interest are:" +
				"<ul>" +
					"<li>" + topic1 + "</li>" +
					"<li>" + topic2 + "</li>" +
					"<li>" + topic3 + "</li>" +
				"</ul>" +
				"</h1>" +
			"</body>" +
			"</html>";

		out.println(page);
	}
}