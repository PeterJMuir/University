import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

public class SampleFX extends Application
{
	private int count = 0;

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();
	}

	public void addContents(Stage primaryStage)
	{
		// Define controls and layout
		Pane root = new FlowPane();

		//	Set scene and stage
		Scene scene = new Scene(root, 400, 300);
		primaryStage.setScene(scene);
	}
}
