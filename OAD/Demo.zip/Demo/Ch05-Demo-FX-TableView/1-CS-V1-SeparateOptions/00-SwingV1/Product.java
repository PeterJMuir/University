public class Product
{
	public final int MISSING_PRICE = -1;

	private String id;
	private String name;
	private double cost;
	private double price;

	public Product(String id, String name, double cost, double price)
	{
		this.id = id;
		this.name = name;
		this.cost = cost;
		this.price = price;
	}

	public void setPrice(double price)
	{
		this.price = price;
	}

	public String getId()
	{
		return id;
	}

	public String getName()
	{
		return name;
	}

	public double getCost()
	{
		return cost;
	}

	public double getPrice()
	{
		return price;
	}

	public String toString()
	{
		return "Product[id: " + id
			+ ", name: " + name
			+ ", cost: " + cost
			+ ", price: " + price + "]";
	}
	public static void main(String [] args)
	{
		Product p = new Product("P01", "Table", 15.00, 30.50);
		System.out.println(p);
	}
}
/*
Q1: I wonder, in terms of MVC, what would be the model, the view and the controller in this application?

Q2: What would be an interesting (not bore people to tears) application which maintain a collection og objects?
*/