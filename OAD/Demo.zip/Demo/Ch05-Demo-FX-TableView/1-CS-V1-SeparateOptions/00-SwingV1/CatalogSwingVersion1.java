// This version is similar to version 2
// i.e.
// 	Each option has a popup dialog
// 	Popup dialogs are created on the fly
// But it is more modular

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.util.*;

public class CatalogSwingVersion1 extends JFrame
{
	private Catalog catalog = new Catalog();
	private JFrame mainFrame = this;

	public CatalogSwingVersion1( )
  	{
 		setTitle("CatalogSystem");
 		setSize(600, 300);
 		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		addContents();
	}

	public void addContents()
	{
		setLayout(new FlowLayout());

		// Option Load Data
		//
		JButton loadDataBT = new JButton("Load Data");
		add(loadDataBT);
		loadDataBT.addActionListener(new LoadDataListener());

		// Option Display Products
		//
		JButton displayProductsBT = new JButton("Display Products");
		add(displayProductsBT);
		displayProductsBT.addActionListener(new DisplayProductsListener());

		// Option Add Product
		JButton addProductBT = new JButton("Add Product");
		add(addProductBT);
		addProductBT.addActionListener(new AddProductListener());


	} // constructor

	// Listener for option Load Data
	//
	class LoadDataListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			try
			{
				catalog.loadData();

				JDialog pop = new JDialog(mainFrame, "Load Data", true);
				pop.setSize(300, 300);
				pop.setLocation(100, 100);
				pop.setVisible(true);

				System.out.println("\n" + catalog);
			}
			catch(Exception exception) {}
		}
	}

	// Listener for option Display Products
	//
	class DisplayProductsListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			try
			{
				String result = catalog.getDisplayString();

				JDialog pop = new JDialog(mainFrame, "Display Products", true);
				pop.setSize(300, 300);
				pop.setLocation(100, 100);
				JTextArea displayTA = new JTextArea(5, 10);
				pop.add(new JScrollPane(displayTA));
				displayTA.setText(result);

				pop.setVisible(true);

				System.out.println("\n" + catalog);
			}
			catch(Exception exception) {}
		}
	} // class DisplayProductsListener


	// Listener for option Add Product
	//
	class AddProductListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			try
			{
				// final JDialog pop = new JDialog(mainFrame, "Add Product", true);
				// JDialog does not work here.Need to use frame
				//
				final JFrame pop = new JFrame();
				pop.setSize(300, 300);
				pop.setLocation(100, 100);

				JLabel idLB = new JLabel("Enter the product ID: ");
				final JTextField idTF = new JTextField(10);

				JLabel nameLB = new JLabel("Product Name: ");
				final JTextField nameTF = new JTextField(10);

				JLabel costLB = new JLabel("Product Cost: ");
				final JTextField costTF = new JTextField(10);

				JLabel priceLB = new JLabel("Product Price: ");
				final JTextField priceTF = new JTextField(10);

				pop.setLayout(new FlowLayout());
				pop.add(idLB);
				pop.add(idTF);

				pop.add(nameLB);
				pop.add(nameTF);

				pop.add(costLB);
				pop.add(costTF);

				pop.add(priceLB);
				pop.add(priceTF);

				pop.setVisible(true);

				final JButton addBT = new JButton("Add");
				final JButton cancelBT = new JButton("Cancel");
				pop.add(addBT);
				pop.add(cancelBT);

				addBT.addActionListener(
					new ActionListener()
					{
						public void actionPerformed(ActionEvent e)
						{
							String id = idTF.getText().trim();
							String name = nameTF.getText().trim();
							double cost = Double.parseDouble(costTF.getText().trim());
							final double price = Double.parseDouble(
								priceTF.getText().trim());

							try
							{
								System.out.println("ADD button pressed inside try");
								catalog.addProduct(id, name, cost, price);
								JOptionPane.showMessageDialog(pop, "Product Added");

								((JButton) e.getSource()).setEnabled(false);
								cancelBT.setEnabled(false);

								// or
								// pop.setVisible(false);
							}
							catch(Exception exception){};
						}
					});

				cancelBT.addActionListener(
					new ActionListener()
					{
						public void actionPerformed(ActionEvent e)
						{
							((JButton) e.getSource()).setEnabled(false);
							addBT.setEnabled(false);
						}
					});

				System.out.println("\n" + catalog);
			}
			catch(Exception exception) {}
		}
	} // class AddProductListener



	public static void main( String [ ] args  )
	{
		new CatalogSwingVersion1().setVisible(true);
	}
}