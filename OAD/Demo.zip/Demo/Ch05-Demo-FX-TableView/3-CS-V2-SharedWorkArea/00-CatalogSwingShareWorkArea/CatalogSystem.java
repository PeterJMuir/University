import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.util.*;

public class CatalogSystem extends JFrame
{
	private Catalog catalog = new Catalog();
	private JTextArea displayTA = new JTextArea(10, 20); // rows, columns
	private JTextField idTF = new JTextField(10);
	private JTextField nameTF = new JTextField(10);
	private JTextField priceTF = new JTextField(10);

	public CatalogSystem( )
  	{
 		setTitle("CatalogSystem");
 		setSize(600, 300);
 		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		addContents();
	}


	public void addContents()
	{
		setLayout(new FlowLayout());
		add(new JScrollPane(displayTA));

		add(new JLabel("id:"));
		add(idTF);

		add(new JLabel("name:"));
		add(nameTF);

		add(new JLabel("price:"));
		add(priceTF);

		// Option Load
		//
		JButton loadDataBT = new JButton("Load Data");
		add(loadDataBT);
		loadDataBT.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent event)
				{
					try
					{
						catalog.loadData();
						JOptionPane.showMessageDialog(null, "Data has been loaded");
						System.out.println("\n" + catalog);
					}
					catch(Exception exception) {}

				}
			});

		// Option Display Products
		//
		JButton displayProductsBT = new JButton("Display Products");
		add(displayProductsBT);
		displayProductsBT.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent event)
				{
					String products = catalog.getDisplayString();
					displayTA.setText(products);
				}
			});

		// Option Search Product
		//
		JButton searchProductBT = new JButton("Search Product");
		add(searchProductBT);
		searchProductBT.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent event)
				{
					String id = idTF.getText();
					Product product = catalog.searchProduct(id);
					displayTA.setText(product.toString());
					nameTF.setText(product.getName());
					priceTF.setText(product.getPrice() + "");
				}
			});

		// Option Search Product
		//
		JButton addProductBT = new JButton("Add Product");
		add(addProductBT);
		addProductBT.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent event)
				{
					String id = idTF.getText();
					String name = nameTF.getText();
					double price = Double.parseDouble(priceTF.getText().trim());
					Product product = catalog.searchProduct(id);

					try
					{
						catalog.addProduct(id, name, price, 0);
					}
					catch(Exception exception){}
				}
			});

		// Option Update Product Price
		//
		JButton updateProductPriceBT = new JButton("Update Product Price");
		add(updateProductPriceBT);
		updateProductPriceBT.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent event)
				{
					String id = idTF.getText();
					double price = Double.parseDouble(priceTF.getText().trim());

					try
					{
						catalog.updateProductPrice(id, price);
					}
					catch(Exception exception){}
				}
			});

			// Option saveDataBT
			//
			JButton saveDataBT = new JButton("Saved Data");
			add(saveDataBT);
			saveDataBT.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						try
						{
							catalog.saveData();
							JOptionPane.showMessageDialog(null, "Data has been saved");
							System.out.println("\n" + catalog);
						}
						catch(Exception exception) {}

					}
				});


	}

	public static void main( String [ ] args  )
	{
		new CatalogSystem().setVisible(true);
	}
}