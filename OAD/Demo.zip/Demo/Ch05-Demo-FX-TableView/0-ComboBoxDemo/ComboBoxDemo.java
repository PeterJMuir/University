import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

import java.util.*;

public class ComboBoxDemo extends Application
{
	private int count = 0;

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Define controls and layout
		String c1 = "choice 1";
		String c2 = "choice 2";
		String c3 = "choice 3";
		String c4 = "choice 4";
		String c5 = "choice 5";
		String c6 = "choice 6";
		String c7 = "choice 7";
		String c8 = "choice 8";

		ComboBox<String>  choice = new ComboBox<String>();
		choice.getItems().addAll(c1, c2, c3, c4, c5, c6, c7, c8);
		choice.setVisibleRowCount(4);
		choice.setEditable(false);

		choice.setPromptText("Choose an item");	// No effect if editable
		choice.setValue(c2);					// or set value

		Button getValueBT = new Button("Get Choice");
		getValueBT.setOnAction((e) ->
			{
				System.out.println(choice.getValue());
			});

		choice.setOnAction((e) ->
			{
				System.out.println("value changed to: " + choice.getValue());
			});

		Pane pane = new FlowPane(choice, getValueBT);
		pane.setStyle("-fx-font-size: 20");

		// 	demo delete
		Button deleteBT = new Button("Delete selected choice");
		deleteBT.setOnAction((e) -> choice.getItems().remove(choice.getValue()));
		pane.getChildren().add(deleteBT);

		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 300);


		stage.setScene(scene);
	}
}
