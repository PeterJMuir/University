import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.geometry.*;

import javafx.stage.*;	// Modality

public class CatalogFXVersion1 extends Application
{
	private Catalog catalog = new Catalog();

	public void start(Stage stage) throws Exception
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();

		// CATCH exceptions
		//
		Thread.currentThread().setUncaughtExceptionHandler((thread, exception) ->
		{
			System.out.println("ERROR: " + exception);
			System.out.println(">> START, thread: " + Thread.currentThread());
		});
	}

	public void addContents(Stage primaryStage) throws Exception
	{
		// Define buttons: one for each option
		//
		Button loadBT = new Button("Load Data");
		Button displayBT = new Button("Display Products");
		Button addBT = new Button("Add Product");

		HBox root = new HBox();
		root.getChildren().addAll(loadBT, displayBT, addBT);
		root.setAlignment(Pos.TOP_CENTER);
		root.setSpacing(20);

		// Load data
		loadBT.setOnAction((e) -> loadData());


		// Display Products
		displayBT.setOnAction((e) -> displayProducts());

		// Add Product
		addBT.setOnAction((e) -> addProduct());

		//	Set scene and stage
		Scene scene = new Scene(root, 400, 300);
		primaryStage.setScene(scene);
	}

	private void loadData()
	{
		Thread.currentThread().setUncaughtExceptionHandler((thread, exception) ->
			{
				System.out.println("ERROR: " + exception);
				System.out.println(">> LOAD DATA, thread: " + Thread.currentThread());
        	});

		try
		{
			catalog.loadData();
		}
		catch(Exception exception)
		{
			throw new RuntimeException(exception.getMessage());
		}

		Label root = new Label("Data Loaded");
		Scene scene = new Scene(root);

		Stage stage = new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);	// comment out & observe
		stage.setScene(scene);
		stage.show();

		System.out.println("\nLOAD DATA:\n" + catalog);	// to verify
	}

	private void displayProducts()
	{
		String result = catalog.toString();	// effectively get all products
		TextArea root = new TextArea(result);
		Scene scene = new Scene(root);

		Stage stage = new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setScene(scene);
		stage.show();
	}

	private void addProduct()
	{
		Label idLB = new Label("Product ID: ");
		TextField idTF = new TextField();
		HBox idHBox = new HBox();
		idHBox.getChildren().addAll(idLB, idTF);

		Label nameLB = new Label("Name: ");
		TextField nameTF = new TextField();
		HBox nameHBox = new HBox();
		nameHBox.getChildren().addAll(nameLB, nameTF);

		Label priceLB = new Label("Price: ");
		TextField priceTF = new TextField();
		HBox priceHBox = new HBox();
		priceHBox.getChildren().addAll(priceLB, priceTF);

		Label onSaleLB = new Label("On Sale: ");
		TextField onSaleTF = new TextField();
		HBox onSaleHBox = new HBox();
		onSaleHBox.getChildren().addAll(onSaleLB, onSaleTF);

		Button doAddBT = new Button("Add Product");
		doAddBT.setOnAction((e) ->
			{
				String id = idTF.getText().trim();
				String name = nameTF.getText().trim();
				double price = Double.parseDouble(priceTF.getText().trim());
				boolean onSale = Boolean.parseBoolean(onSaleTF.getText().trim());

				try
				{
					catalog.addProduct(id, name, price, onSale);
				}
				catch(Exception exception)
				{
					throw new RuntimeException(exception.getMessage());
				}
				System.out.println("\nADD PRODUCT:\n" + catalog); // to verify
			});

		VBox root = new VBox();
		root.getChildren().addAll(idHBox, nameHBox, priceHBox, onSaleHBox, doAddBT);

		Stage stage = new Stage();
		stage.setScene(new Scene(root));
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.show();


		Thread.currentThread().setUncaughtExceptionHandler((thread, exception) ->
			{
				System.out.println("ERROR: " + exception);
				System.out.println(">> ADD PRODUCT, thread: " + Thread.currentThread());
        	});


	}
}
