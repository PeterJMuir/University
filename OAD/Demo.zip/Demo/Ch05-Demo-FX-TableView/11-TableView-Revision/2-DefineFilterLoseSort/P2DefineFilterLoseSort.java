import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.geometry.*;
import java.util.*;
import java.io.*;
import javafx.collections.*;
import javafx.collections.transformation.*;
import javafx.scene.control.cell.*;
import javafx.beans.property.*;

public class P2DefineFilterLoseSort extends Application
{
	// Data source controller
	// Catalog catalog = new Catalog();

	public void start(Stage stage) throws Exception
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();
	}

	public void addContents(Stage stage) throws Exception
	{
		// Create the table view
		TableView<Product> tableView = new TableView<Product>();

		// Define (two) table columns
		// setCellValueFactory instructs the vew on how to display the column
		TableColumn<Product, String> idColumn = new TableColumn<Product, String>("Id");
		idColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("Id"));
		tableView.getColumns().add(idColumn);

		TableColumn<Product, String> nameColumn = new TableColumn<Product, String>("Name");
		nameColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("Name"));
		tableView.getColumns().add(nameColumn);

		TableColumn<Product,Double> priceColumn = new TableColumn<Product, Double>("Price");
		priceColumn.setCellValueFactory(new PropertyValueFactory<Product, Double>("Price"));
		tableView.getColumns().add(priceColumn);

		TableColumn<Product,Boolean> onSaleColumn = new TableColumn<Product,Boolean>("OnSale");
		onSaleColumn.setCellValueFactory(new PropertyValueFactory<Product, Boolean>("OnSale"));
		tableView.getColumns().add(onSaleColumn);

		// Prepare data and set the data to the table view
		List<Product> list = new ArrayList<Product>();
		list.add(new Product("p40", "lights", 40.0, true));
		list.add(new Product("p10", "table", 10.0, false));
		list.add(new Product("p20", "chair", 20.0, true));
		list.add(new Product("p30", "desk", 30.0, false));
		ObservableList<Product> tableData= FXCollections.observableArrayList(list);
		tableView.setItems(tableData);

		/**
		 *	Define filter (search)
		 */

		// Create a filtered list for table data (default: select all products)
		FilteredList<Product> filteredList = new FilteredList<>(tableData, p -> true);
		tableView.setItems(filteredList);	// lose automatic sort!

		// Define a text field to get fiter text
		Label filterLB = new Label("Filter by Product Name: ");
		TextField filterTF = new TextField();
		HBox filterHBox = new HBox(filterLB, filterTF);

		// Define change listener to filter text field
		filterTF.textProperty().addListener((observable, oldValue, newValue) ->
			{
				filteredList.setPredicate(product ->
					{
						// If filter text is empty, display all products
						if (newValue == null || newValue.isEmpty())
						{
							return true;
						}

						// Otherwise, display products with name partially matches filter text
						String filterString = newValue.toUpperCase();
						if (product.getName().toUpperCase().contains(filterString))
						{
							return true;
						}
						else
						{
							return false;
						}
					});
			  });

		// set scene and stage
		VBox root = new VBox();
		root.getChildren().addAll(tableView, filterHBox);
		Scene scene = new Scene(root);
		stage.setScene(scene);
	}
}