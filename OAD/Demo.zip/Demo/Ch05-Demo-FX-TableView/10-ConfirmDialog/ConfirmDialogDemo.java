import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

import java.util.*;
import javafx.stage.*;
import javafx.beans.property.*;

public class ConfirmDialogDemo extends Application
{
	private int count = 0;

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();
	}

	public void addContents(Stage stage)
	{
		Button confirmBT = new Button("Confirm");
		confirmBT.setOnAction((e) ->
			{
				boolean answer = getConfirmation();
				System.out.println(answer);
			});

		//	Set scene and stage
		FlowPane pane = new FlowPane(confirmBT);
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}

	private boolean getConfirmation()
	{
		BooleanProperty ans  = new SimpleBooleanProperty(false);
		Stage stage = new Stage();

		Button yesBT = new Button("Yes");
		yesBT.setOnAction((e) ->
			{
				ans.set(true);
				stage.close();
			});

		Button noBT = new Button("No");
		noBT.setOnAction((e) ->
			{
				ans.set(false);
				stage.close();
			});
		HBox root = new HBox(yesBT, noBT);
		Scene scene = new Scene(root);
		stage.setScene(scene);

		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();		// Must use showAndWait

		return ans.get();
	}
}
