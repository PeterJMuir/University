import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class S3CatServletEdit extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		Product product = null;
		try
		{
			String id = request.getParameter("id");
			product = CatalogDSC.searchProduct(id);
		}
		catch(Exception e){}

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		printPageForGET(out, product);
	}

	// This doGet methods is called when we press the EDIT button in
	// display table. It presents a form to change the data
	//
	private void printPageForGET(PrintWriter out, Product product)
	{

		out.println( " "
			+	"<html><body><h1>Edit Product</h1>"
			+ 	"<form action='edit' method='POST'>"

			+ 	"id: <input type='text' readonly name='id' value='" + product.getId()
						+ "'></input><br>"


			+ 	"Name: <input type='text' readonly name='name' value='" + product.getName()
						+ "'></input><br>"

			+ 	"Price: <input type='text' name='price' value='" + product.getPrice()
						+ "'></input><br>"

			+ 	"Is On Sale: <input type='checkbox' name='onSale'"
						+ (product.isOnSale()? "checked": "")
						+ "></input><br>"

			+	"<input type='submit' value='Submit'></input>"

			+ 	"<button type='button' onClick=\"window.location.href='list'\">"
					+"Cancel </button>"
			+	"</form>"
			+	"</body></html>");
	}

	// This doPost methods is called when we press the SUBMIT button in
	// the edit form.
	//
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
  		List<String> messages = new ArrayList<String>();
		Product product = null;

		try
		{
			String id = request.getParameter("id");
			String name = request.getParameter("name");
			double price = Double.parseDouble(request.getParameter("price").trim());
			boolean onSale = request.getParameter("onSale")== null? false: true;

			CatalogDSC.updateProductPrice(id, price);
			CatalogDSC.updateProductOnSale(id, onSale);

        	messages.add("EDIT product: successful!");
   	}
   	catch (Exception e)
   	{
			messages.add(e.getMessage());
    	}

  		// Generation all HTML to be displayed in browser;
  		response.setContentType("text/html");
   	PrintWriter out = response.getWriter();
   	printPageForPOST(out, messages);
	}

 	private void printPageForPOST(PrintWriter out, List<String> messages)
 	{
		out.println( "<html><body><h2>EDIT Product: Success/Errors:</h2>");
		out.println(messages);
		out.println(""
			+	"<form>"
			+ 	"<button type='button' onClick=\"window.location.href='list'\">"
					+ "Return to List </button>"
			+	"</form>"
			+	"</body></html>");
   	out.flush();
   }

}
