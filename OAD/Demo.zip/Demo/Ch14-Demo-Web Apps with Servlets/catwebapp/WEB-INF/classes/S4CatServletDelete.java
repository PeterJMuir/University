import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;


public class S4CatServletDelete extends HttpServlet
{
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
    {
        delete(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
    {
        delete(request, response);
    } // doPost

    public static final String TEXT_HTML_CONTENT_TYPE = "text/html";

    public static final String EVENT_DELETE = "delete";

    private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
    {
      List<String> messages = new ArrayList<String>();

   	String id = request.getParameter("id");

		try
		{
			CatalogDSC.removeProduct(id);
			String message = "Delete productwith id " +  id + ": successful!";
			messages.add(message);
		}
		catch (Exception e)
		{
			messages.add(e.getMessage());
     	}

      // Generate HTML page
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();
      printPage(out, messages);
   }


   private void printPage(PrintWriter out, List<String> messages)
   {
  		out.println( "<html><body><h2>Delete Product: Success/Errors:</h2>");
  		out.println(messages);
  		out.println(""
  			+	"<form>"
  			+ 	"<button type='button' onClick=\"window.location.href='list'\">"
  					+ "Return to List </button>"
  			+	"</form>"
  			+	"</body></html>");
     	out.flush();
    }
}
