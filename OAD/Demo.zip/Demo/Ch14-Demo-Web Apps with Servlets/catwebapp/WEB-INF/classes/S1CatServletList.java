import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class S1CatServletList extends HttpServlet
{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
 	{
   	doGet(request, response);
 	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		List<String> errorMessages = new ArrayList<String>();
		List<Product> products = null;
		try
		{
			products = CatalogDSC.getAllProducts();
		}
		catch(Exception e)
		{
			errorMessages.add(e.getMessage());
		}

  		response.setContentType("text/html");
     	PrintWriter out = response.getWriter();
    	printPage(out, products, errorMessages);
      out.flush();
    }

    private void printPage(PrintWriter out, List<Product> products, List<String> errorMessages)
    {
		 // As a general approach, we can examine the error messages, and if there
		 // messages, we return a HTML ppage containg those messages
		 // For simplicity, we ignore this in this example

		 out.println( ""
		 	+ "<HTML>"
		 	+ "<body>"
		 	+ "<h1> Product Catalog </h1>");

		 printTable(out, products);

		 out.println( ""
		 	+ "</body>"
		 	+ "</HTML>");
	 }

	 private void printTable(PrintWriter out, List<Product> products)
	 {
		 out.println( "<table border='1'cellpadding='2' cellspacing='2'>");
		 out.println( ""
			+	"<tr>"
			+	"<td> ID  </td>"
			+ 	"<td> Name </td>"
			+ 	"<td> Price </td>"
			+ 	"<td> Is On Sale </td>"
			+ 	"<td> <button onclick=\"window.location.href='add'\">add</button> </td>"
			+	"</tr>");

		 for(Product product: products)
		 {
			 out.println( ""
				 +	"<tr>"
				 +	"<td>" +	product.getId() + "</td>"
				 + "<td>" +	product.getName() + "</td>"
				 + "<td>" +	product.getPrice() + "</td>"
				 + "<td>" +	product.isOnSale() + "</td>"
				 + "<td><button onclick=\"window.location.href='edit?id="
				 		+ product.getId() + "'\">edit</button></td>"

             + "<td><button onclick=\"window.location.href='delete?id="
             		+ product.getId() + "'\">delete</button></td>"
				 +"</tr>");
		 }
		 out.println( "</table>");
	 }
}
