package model;

/**
 * Created by Sameer Cooshna on 29/08/14.
 */
public abstract class AbstractModel {
}
