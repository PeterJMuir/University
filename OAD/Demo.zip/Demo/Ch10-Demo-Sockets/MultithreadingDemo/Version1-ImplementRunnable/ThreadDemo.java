// Implement Runnable version
//
public class ThreadDemo
{
	public static void main(String args[])
   {
      Runnable generator1 = new NumberGenerator( 10, 20, 1000 );
		Runnable generator2 = new NumberGenerator( 1000, 2000, 2000 );

		Thread thread1 = new Thread(generator1);
		Thread thread2 = new Thread(generator2);

		thread1.start();
		thread2.start();
   }
}

