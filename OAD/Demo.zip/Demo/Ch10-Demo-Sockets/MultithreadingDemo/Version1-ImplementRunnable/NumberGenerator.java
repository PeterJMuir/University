public class NumberGenerator implements Runnable
{
	private int lower;
	private int upper;
	private int interval;

	public NumberGenerator(int lower, int upper, int interval)
	{
		this.lower = lower;
		this.upper = upper;
		this.interval = interval;
	}
	public void run( )
	{
		while (true)
		{
			int number = lower + (int) (Math.random() * (upper - lower + 1));
			System.out.println(number);

			try
			{
				Thread.sleep(interval);
			}
			catch(Exception e) {}
		}
	}
}
