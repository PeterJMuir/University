/*	DoubleServer4.java

	Service: Receives an integer n and returns 2 * n.
	Delivery: Can serve many clients simultaneously. Keeps serving a client
	until it 'disconnects'.
*/

import java.io.*;
import java.net.*;

class DoubleServer4
{
	public static void main( String [] args ) throws IOException
	{
		// create a server socket
		ServerSocket serverSocket = new ServerSocket(7000);
		System.out.println("Server starts at " + java.time.LocalDateTime.now());

		while (true )
		{
			// accept a connection
			Socket socket = serverSocket.accept();
			System.out.println("Created a socket");

			// create a thread to manage the socket
			SocketThread socketThread = new SocketThread( socket);
			socketThread.start();
		}
	}
}