/* 	Thread to manage the socket (i.e. the connection)
*/
import java.io.*;
import java.net.*;

public class SocketThread extends Thread
{
	Socket socket;
	BufferedReader inputFromClient;
	PrintWriter outputToClient;

	SocketThread( Socket socket) throws IOException
	{
		this.socket = socket;
		inputFromClient = new BufferedReader(
			new InputStreamReader( socket.getInputStream()));
		outputToClient = new PrintWriter( socket.getOutputStream(), true );
	}

	public void run( )
	{
		while (true )
		{
			try
			{	// get a number from the client
				int n = Integer.parseInt( inputFromClient.readLine().trim());

				// send back twice the number
				int twice = n * 2;
				outputToClient.println( twice + "" );
			}
			catch( Exception e )
			{
				System.out.println( e );
				socket = null;
				break;
			}
		}
	}
}