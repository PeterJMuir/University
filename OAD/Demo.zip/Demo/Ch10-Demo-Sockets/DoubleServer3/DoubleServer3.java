/*  DoubleServer3.java

Service: Receives an integer n and returns 2 * n.

Service Delivery: Can serve many clients - one at a time. Keeps serving a client until the
client 'disconnects' itself by terminating its program. Then the next client can take over.
*/

import java.io.*;
import java.net.*;
class DoubleServer3
{
	public static void main( String [] args ) throws IOException
	{
		// create a server socket
		ServerSocket serverSocket = new ServerSocket( 7000 );

		Socket socket = null;
		BufferedReader inStream = null;
		PrintWriter outStream = null;

		while (true )
		{
			// create a socket and input/output streams
			if ( socket == null )
			{
				socket = serverSocket.accept();
				inStream = new BufferedReader(
					new InputStreamReader( socket.getInputStream()));
				outStream = new PrintWriter( socket.getOutputStream(),true );
			}

			try
			{	// get a number from the client
				int n = Integer.parseInt( inStream.readLine());

				// send back twice the number
				int twice = n * 2;
				outStream.println( twice + "" );
			}
			catch( Exception e )
			{
				System.out.println( e );
				socket = null;
			}
		}

		// System.out.println( "Double server has closed!" );
	}
}
