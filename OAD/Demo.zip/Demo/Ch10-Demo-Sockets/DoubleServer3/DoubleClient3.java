/*
DoubleClient3.java (the same as DoubleClient2)
This client program connects to the socket, sends it a number and 	receives double of it. The requests are repeated until the user press: Control-C or Control-Z.
*/
import java.io.*;
import java.net.*;
import java.util.*;

class DoubleClient3
{
	public static void main( String [] args ) throws IOException
	{
		// define an object to represent the keyboard
		Scanner keyboard =
			new Scanner(System.in);

		// create a socket and input/output streams
		//
		Socket socket = new Socket( "localhost", 7000 );

		BufferedReader inStream = new BufferedReader(
			new InputStreamReader(
				socket.getInputStream()));

		PrintWriter outStream=
			new PrintWriter( socket.getOutputStream(), true );

		// send number to get the double. Terminate with CTRL-C
		//
		while (true )
		{	// get a number and send it
			System.out.print( "Enter a number: " );
			int n = Integer.parseInt( keyboard.nextLine());
			outStream.println( n + "");

			// receive the result and print it
			int twice = Integer.parseInt( inStream.readLine());
			System.out.println( "Receives: " + twice );
		}
	}
}
