// the same as DoubleClient5

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import javafx.scene.text.*;
import javafx.scene.paint.*;
import javafx.geometry.*;

import java.net.*;
import java.util.*;
import java.io.*;

public class DoubleClient6 extends Application
{
	public void start(Stage stage) throws Exception
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();

		Thread.currentThread().setUncaughtExceptionHandler((thread, exception) ->
		{
			System.out.println("ERROR: " + exception);
		});
	}

	private void addContents(Stage stage) throws Exception
	{
		// Define controls and layout
		Label numberLB = new Label("Enter a number: " );
		TextField numberTF = new TextField();
		Button doubleBT = new Button("Get Double the Number");
		TextField resultTF = new TextField();

		HBox row1 = new HBox(numberLB, numberTF);
		HBox row2 = new HBox(doubleBT, resultTF);
		VBox root = new VBox(row1, row2);
		Scene scene = new Scene(root);
		stage.setScene(scene);

		// set style
		{	row1.setAlignment(Pos.CENTER_LEFT);
			row2.setAlignment(Pos.CENTER_LEFT);
			root.setStyle("-fx-font-size: 20; -fx-spacing:10; -fx-padding: 10");
		}

		Socket socket = new Socket("localhost", 7000);
		final Scanner inputFromServer = new Scanner(socket.getInputStream());
		final PrintWriter outputToServer = new PrintWriter(socket.getOutputStream(), true);

		doubleBT.setOnAction((e) ->
			{
				try
				{
					String number = numberTF.getText().trim();
					outputToServer.println(numberTF.getText().trim());

					resultTF.setText(inputFromServer.nextLine());

				}
				catch(Exception exception)
				{
					System.out.println(exception);
					throw new RuntimeException("Get error when accessing server!");
				}
			});
	}
}
