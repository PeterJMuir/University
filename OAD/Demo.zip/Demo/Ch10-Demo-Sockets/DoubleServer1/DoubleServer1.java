/* DoubleServer1.java

This server receives an integer n and returns 2*n (the double of n).
The server serves one client only. Its also provides only one serve and
then terminates itself. We use 7000 for the port number.
*/
import java.io.*;
import java.net.*;
class DoubleServer1
{
	public static void main( String [] args ) throws IOException
	{
		// create a server socket
		ServerSocket serverSocket = new ServerSocket(7000);

		// create a socket - this is done only upon a client�s request
		System.out.println("\nWaiting for a request from a client ...");
		Socket socket = serverSocket.accept( );

		// create reader and writer to communicate with client
		BufferedReader inputFromClient =
			new BufferedReader( new InputStreamReader(
				socket.getInputStream()));
		PrintWriter outputToClient=
			new PrintWriter( socket.getOutputStream(), true );

		System.out.println("\nHave received a request, created a socket,"
			+ " and input/output channel");
		System.out.println("Waiting for an integer from a client ...");

		// get a number from the client and send back twice the number
		int n = Integer.parseInt( inputFromClient.readLine());
		int d = n * 2;
		outputToClient.println( d + "" );

		// terminates the program
		System.out.println("\nTerminates the program");
	}
}