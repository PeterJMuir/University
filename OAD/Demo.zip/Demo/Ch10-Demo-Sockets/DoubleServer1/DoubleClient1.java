/*  DoubleClient1.java
This client program connect to the server (localhost, 7000), sends it
a number and receives the double of it.
*/
import java.io.*;
import java.net.*;
import java.util.*;	// for Scanner class

public class DoubleClient1
{
	public static void main( String [] args ) throws IOException
	{
		// define a Scanner instance to read from the keyboard
		Scanner keyboard = new Scanner(System.in);

		// create a socket (request a connection) and input/output streams
		// note that server is the name of the server on which the previous
		// program (DoubleServer1) was run.

		String server = "localhost";
		int port = 7000;
		Socket socket = new Socket(server, port );

		BufferedReader inputFromServer = new BufferedReader( new
			InputStreamReader(socket.getInputStream()));

		PrintWriter outputToServer = new PrintWriter(
			socket.getOutputStream(), true );

		// get a number from the keyboard and send it
		System.out.print( "Enter a number: " );
		int n = Integer.parseInt( keyboard.nextLine());
		outputToServer.println( n + "");

		// receive the result and print it
		int twice = Integer.parseInt( inputFromServer.readLine());
		System.out.println( "Receives: " + twice );
	}
}