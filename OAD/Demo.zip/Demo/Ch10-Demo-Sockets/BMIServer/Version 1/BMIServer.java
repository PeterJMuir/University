import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.util.Scanner;
import java.io.PrintWriter;

public class BMIServer
{
	public static void main(String [] args) throws IOException
	{
		//	Create a server socket
		ServerSocket serverSocket = new ServerSocket(7000);

		// Create connection at client's request
		Socket socket = serverSocket.accept();
		Scanner in = new Scanner(socket.getInputStream());
		PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

		double weight = Double.parseDouble(in.nextLine().trim());
		int heightInCm = Integer.parseInt(in.nextLine().trim());
		double height = heightInCm/ 100.0;
		double bmi =  weight/ (height * height);

		out.printf("%4.2f\n", bmi);
		out.println("You are such and such");

		System.out.println("BMI server has terminated.");

	}
}