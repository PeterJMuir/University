import java.net.Socket;
import java.util.Scanner;
import java.io.PrintWriter;

public class BMIClient
{
	public static void main(String [] ars) throws Exception
	{
		Socket socket = new Socket("localhost", 7000);
		Scanner in = new Scanner(socket.getInputStream());
		PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

		Scanner kb = new Scanner(System.in);
		System.out.print("Enter weight in kg: ");
		String weight = kb.nextLine().trim();
		System.out.print("Enter height in cm: ");
		String height = kb.nextLine().trim();
		out.println(weight);
		out.println(height);

		double bmi = Double.parseDouble(in.nextLine().trim());
		String message = in.nextLine();

		System.out.println("bmi: " + bmi);
		System.out.println("message: " + message);
	}
}