import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.util.Scanner;
import java.io.PrintWriter;

public class CalculatorThread extends Thread
{
	Socket socket;

	public CalculatorThread(Socket socket)
	{
		this.socket = socket;
	}

	public void run()
	{
		try
		{
			// Create connection at client's request
			Scanner in = new Scanner(socket.getInputStream());
			PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

			double weight = Double.parseDouble(in.nextLine().trim());
			int heightInCm = Integer.parseInt(in.nextLine().trim());
			double height = heightInCm/ 100.0;
			double bmi =  weight/ (height * height);

			out.printf("%4.2f\n", bmi);
			out.println("You are such and such");
		}
		catch(Exception e){}
	}
}