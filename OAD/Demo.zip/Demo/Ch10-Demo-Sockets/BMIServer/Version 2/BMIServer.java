import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.util.Scanner;
import java.io.PrintWriter;

public class BMIServer
{
	public static void main(String [] args) throws IOException
	{
		//	Create a server socket
		ServerSocket serverSocket = new ServerSocket(7000);


		while(true)
		{
			// Create connections at client's request
			Socket socket = serverSocket.accept();
			CalculatorThread thread = new CalculatorThread(socket);
			thread.start();
		}
	}
}