/*
DoubleClient2.java
This client program connects to the server, sends it a number and receives the
double of it.

The requests are repeated until the user presses Control-C or Control-Z.
*/
import java.io.*;
import java.net.*;
import java.util.*;

class DoubleClient2B
{
	public static void main( String [] args ) throws IOException
	{
		// define Scanner instance to read from the keyboard
		Scanner keyboard = new Scanner(System.in);

		// create a socket and input/output streams
		Socket socket = new Socket( "localhost", 7000 );

		BufferedReader inStream = new BufferedReader(
			new InputStreamReader(
				socket.getInputStream()));

		PrintWriter outStream=
			new PrintWriter( socket.getOutputStream(), true );

		// send number to get the double (or terminate with CTRL-C)
		while (true )
		{
			// get a number and send it
			System.out.print( "Enter a number: " );
			String inputString = keyboard.nextLine();

			if(inputString.length() == 0)
			{
				break;
			}

			int n = Integer.parseInt(inputString.trim());
			outStream.println( n + "");

			// receive the result and print it
			int twice = Integer.parseInt( inStream.readLine());
			System.out.println( "Receives: " + twice );
		}
	}
}
