/* DoubleServer2.java

This server receives an integer n and returns 2*n. The server serves one client only.
It keeps serving until the client terminates its program and, by this action, causes
the connection to be closed.
*/

import java.io.*;
import java.net.*;
class DoubleServer2
{
	public static void main( String [] args ) throws IOException
	{
		// create a server socket
		ServerSocket serverSocket = new ServerSocket(7000);
		System.out.println("\nServer creates at " + java.time.LocalDateTime.now());

		// create a socket
		Socket socket = serverSocket.accept();

		// create and and input/output streams
		BufferedReader inStream = new BufferedReader(
			new InputStreamReader(socket.getInputStream()));

		PrintWriter outStream=
			new PrintWriter(socket.getOutputStream(), true);

		System.out.println("\nCreated sockets and communication channel\n"
			+ "ready to serve the client ...");

		//	keeps serving the double of the input until an exception occurs
		while (true )
		{
			try
			{
				// get a number from the client
				int n = Integer.parseInt( inStream.readLine());

				// send back twice the number
				int twice = n * 2;
				outStream.println( twice + "" );
			}
			catch( Exception e )
			{
				System.out.println( e );
				break;
			}
		}

		System.out.println( "The Double server has closed!" );
	}
}