import java.lang.reflect.*;
import org.apache.commons.beanutils.PropertyUtils ;	// in lib directory

public class Tester
{
	public static void main(String [] args) throws Exception
	{
		// get the object that represents class Person
		Class personClass = Person.class;


		// 1.	Can get all the declared fields
		Field [] fields =  personClass.getDeclaredFields();
		System.out.println("\nDeclared fields: ");
		for(Field f: fields)
		{
			System.out.println(f);
				// private java.lang.String Person.name
				// private int Person.age
		}


		// 2.	Can get all the declared methods
		Method [] methods =  personClass.getDeclaredMethods();
		System.out.println("\nDeclared methods: ");
		for(Method m: methods)
		{
			System.out.println(m);
		}


		// 3.	Can get a field by its name
		Field field = Person.class.getDeclaredField("age");
		System.out.println("\nfield: " + field);


		// 4.	Can get the value of a given field of an object
		Person person = new Person("peter", 30);
		int fieldValue = new Integer
			(PropertyUtils.getProperty(person, field.getName()).toString());
				// require get method
				// Also need toString() to convert an Object into a String

		System.out.println("\nfield value: " + fieldValue);
	}
}