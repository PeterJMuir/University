import java.lang.reflect.Field;

public class BreakEncapsulation
{
    public static void main(String args[]) throws Exception
    {
        Person person = new Person("Peter");

        Field field = person.getClass().getDeclaredField("name");
        field.setAccessible(true);

        System.out.println("Attribute " + field.getName() + " has value "
                + field.get(person));

        field.set(person, "Paul");
        System.out.println("Attribute " + field.getName() + " has value "
                + field.get(person));

    }
}