/*
annotation interface Min
*/
import java.lang.annotation.*;

@Target(ElementType.FIELD)
// This is an annotation for a field (attribute)

@Retention(RetentionPolicy.RUNTIME)
// To be used at runtime

public @interface Min
{
	int value();
	boolean inclusive() default true;
}