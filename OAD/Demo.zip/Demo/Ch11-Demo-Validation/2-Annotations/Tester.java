import java.lang.reflect.*;
import java.lang.annotation.*;
import org.apache.commons.beanutils.PropertyUtils ;

public class Tester
{
	public static void main(String [] args) throws Exception
	{
		Person p = new Person("peter", 22);

		// Get the Field object representing field age
		Field field = p.getClass().getDeclaredField("age");

		// Get all annotation instances of field age
		Annotation [] annotations = field.getDeclaredAnnotations();
		for(Annotation a: annotations)
		{
			System.out.println("a: " + a);
		}

		// Get the Min annotation instance of the field
		// and the values of the parameter of the annotation instance
		//
		Min annotationInstance = field.getAnnotation(Min.class);

		double value = annotationInstance.value();
		boolean inclusive = annotationInstance.inclusive();

		System.out.println("\nAnnotation parameters:");
		System.out.println("value: " + value);
		System.out.println("inclusive: " + inclusive);

		// Get the value of field of an object
		// In this case, it is the age of a Person object
		//
		Person person = new Person("Peter", 30);

		int fieldValue = new Integer
			(PropertyUtils.getProperty(person, field.getName()).toString());

		System.out.println("\nfield value: " + fieldValue);
	}
}