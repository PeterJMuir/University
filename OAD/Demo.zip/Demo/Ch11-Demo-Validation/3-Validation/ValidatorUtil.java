import org.apache.commons.beanutils.PropertyUtils;
import java.lang.reflect.Field;

import java.util.List;
import java.util.ArrayList;

public class ValidatorUtil
{
	public static void validate(Validated pojo) throws ValidationException
	{
		 String errorMessages = new String();
		 for (String error : validateFields(pojo))
		 {
		   	errorMessages += "\n " + error;
	 	 }

		 if (!errorMessages.equals(new String()))
		 {
		     throw new ValidationException("Validation Errors: " + errorMessages);
		 }
	}

	private static List<String> validateFields(Validated pojo)
	{
		List<String> errors = new ArrayList<String>();

		try
		{
			for(Field field: pojo.getClass().getDeclaredFields())
			{
				final Min min = field.getAnnotation(Min.class);
				// does the field has an @Min annotation?

				if(min != null)	// field has an @Min annotation
				{
					// get the value of the field for the pojo
					//
					final double fieldValue = new Double
						(PropertyUtils.getProperty(pojo, field.getName()).toString());

					final boolean valid =
						min.inclusive()? fieldValue >= min.value(): fieldValue > min.value();

					if(!valid)
					{
						errors.add("\n[" + field.getName() + ": " +	fieldValue
							+ " is too small!]");
					}
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return errors;
	}
}