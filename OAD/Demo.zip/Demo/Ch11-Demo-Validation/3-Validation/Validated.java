public interface Validated
{}