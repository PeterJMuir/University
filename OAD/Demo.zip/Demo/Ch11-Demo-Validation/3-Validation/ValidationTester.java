import java.util.List;

public class ValidationTester
{
	public static void main(String [] args)
	{
		Product product = new Product();
		product.setId("P10");
		product.setName("chair");
		product.setPrice(0);

		System.out.println("product: " + product + "\n");

		try
		{
			ValidatorUtil.validate(product);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

		Person person = new Person("peter", 19);
		System.out.println("\nperson: " + person + "\n");

		try
		{
			ValidatorUtil.validate(person);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

		person = new Person("paul", 20);
		System.out.println("\nperson: " + person + "\n");

		try
		{
			ValidatorUtil.validate(product);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
}

/*
-----------------------------------------------------------------------------
Compile and run:

Put jar files in subdir lib
Compile: javac -cp .;lib\* *.java
Run: java -cp ".;lib\*" ValidationTester
-----------------------------------------------------------------------------
Output:

>java -cp ".;lib\*" ValidationTester

product: Product[id: P10, name: chair, price: 0.0]

Validation Errors:

[price: 0.0 is too small!]

person: Person[name: peter, age: 19]

Validation Errors:

[age: 19.0 is too small!]

person: Person[name: paul, age: 20]

Validation Errors:

[price: 0.0 is too small!]
--------------------------------------------------------------------------
*/