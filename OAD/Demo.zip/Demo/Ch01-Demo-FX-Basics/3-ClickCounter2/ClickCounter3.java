import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.text.*;		// Font
import javafx.scene.paint.*;		// Color
import javafx.geometry.*;			// Pos

public class ClickCounter3 extends Application
{
	private int counter = 0;	// attribute

	public static void main(String[] args)
	{
		Application.launch(args);
	}

	@Override
	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle("Click Counter");
		stage.show();
	}

	private void addContents(Stage stage)
	{
		// Create the Label
		Label label = new Label();
		label.setText("You have not clicked the button.");
		label.setFont(Font.font(20));

		// Create the button
 		Button button = new Button();
		button.setText("Click me please!");
		button.setOnAction(e ->
			{
				counter++;
				if (counter == 1)
				{
					label.setText("You have clicked once.");
				}
				else
				{
					label.setText("You have clicked " + counter + " times." );
				}
			});

		// Add the label and the button to a border pane
		BorderPane pane = new BorderPane();
		pane.setTop(button);
		BorderPane.setAlignment(button, Pos.CENTER);
		pane.setCenter(label);

    	// Define the scene
   	Scene scene = new Scene(pane, 400, 300);

   	// Set the stage
		stage.setScene(scene);
	}
}