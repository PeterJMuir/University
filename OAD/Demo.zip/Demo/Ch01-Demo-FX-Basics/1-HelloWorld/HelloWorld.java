import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.*;		// BorderPane
import javafx.scene.control.*;	// Label

public class HelloWorld extends Application
{
	public static void main(String[] args)
	{
	    Application.launch(args);
  	}

	@Override
	public void start(Stage stage)
	{
		// Define label (control)
		Label label = new Label("Hello World!");

		// Define layout (container)
		BorderPane pane = new BorderPane();
		pane.setCenter(label);

		// Define the scene
		Scene scene = new Scene(pane, 400, 300);

		// Set the stage
		stage.setScene(scene);
		stage.setTitle("Hello World");
		stage.show();
	}
}