import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;	// Pos

public class ClickCounter extends Application
{
	public static void main(String[] args)
	{
		Application.launch(args);
	}

	int counter = 0;

	@Override public void start(Stage stage)
	{
		// Create the Label
		Label label = new Label();
		label.setText("You have not clicked the button.");

		// Create the button
 		Button button = new Button();
		button.setText("Click me please!");
		button.setOnAction(e ->
			{
				counter++;
				if (counter == 1)
				{
					label.setText("You have clicked once.");
				}
				else
				{
					label.setText("You have clicked " + counter + " times." );
				}
			});

		// Add the label and the button to a layout pane
		BorderPane pane = new BorderPane();
		pane.setTop(button);
		pane.setCenter(label);

    	// Create the scene
   	Scene scene = new Scene(pane, 400, 300);

   	// Set the scene to the stage, set the stage's title
    	// and show the stage
		stage.setScene(scene);
		stage.setTitle("Click Counter");
		stage.show();
	}
}