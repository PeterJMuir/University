import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.scene.paint.*;
import javafx.geometry.*;

public class LifeCycleIconizeEvents extends Application
{
	public static void main(String[] args)
	{
		Application.launch(args);
	}

	public void init()
	{
		System.out.println(">> init() is called.");
	}

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());

		// Register a handler with iconified property
		stage.iconifiedProperty().addListener((observableValue, oldValue, newValue) ->
			{
				if (observableValue.getValue())
					System.out.println(">> Stage iconified");
				else
					System.out.println(">> Stage deiconified");
			});

		stage.show();
	}

	private void addContents(Stage stage)
	{
		// Define controls and layout
		Button bt = new Button("Click me");
		bt.setOnAction(e ->
			{
				System.out.println(">> The button is clicked.");
			});

		FlowPane pane = new FlowPane();
		pane.getChildren().add(bt);

		//	Define the scene and set the stage
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}

	public void stop()
	{
		System.out.println("stop() is called.");
	}
}
