import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import javafx.scene.text.*;
import javafx.scene.paint.*;
import javafx.geometry.*;

public class SampleFX extends Application
{
	public static void main(String[] args)
	{
		Application.launch(args);
	}

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();
	}

	private void addContents(Stage stage)
	{
		// Define controls and layout
		FlowPane pane = new FlowPane();

		//	Define the scene and set the stage
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
	}
}
