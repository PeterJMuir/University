import java.sql.*;
import java.util.*;	// ArrayList

public class CatalogDSC
{
	private static Connection connection;
	private static Statement statement;
	private static PreparedStatement preparedStatement;

	public static void connect() throws SQLException
	{
		String url = "jdbc:mysql://localhost:3306/CatalogDB";
		String user = "";
		String password = "";
		connection = DriverManager.getConnection(url, user, password);
		statement = connection.createStatement();
	}

	public static void disconnect() throws SQLException
	{
		if(preparedStatement != null) preparedStatement.close();
		if(statement != null) statement.close();
		if(connection != null) connection.close();
	}

	// SEARCH for a product by product ID
	// return null if the product is not found
	//
	public static Product searchProduct(String id) throws Exception
	{
		connect();

		String queryString = "select * from Product where id = ?";
		preparedStatement = connection.prepareStatement(queryString);
		preparedStatement.setString(1, id);
		ResultSet rs = preparedStatement.executeQuery();

		Product product = null;

		if(rs.next())	// i.e. the product exists
		{
			String name = rs.getString(2);
			double price = rs.getDouble(3);
			boolean onSale = rs.getBoolean(4);
			product = new Product(id, name, price, onSale);
		}

		disconnect();

		return product;
	}


	// ADD a product
	public static void addProduct(String id, String name, double price, boolean onSale) throws Exception
	{
		// pre: product id is new

		Product product = searchProduct(id);
		boolean pre = (product == null);
		if(! pre)
		{
			String msg = "Product id " + id + " is not new!";
			System.out.println("\nERROR: " + msg);
			throw new Exception(msg);
		}

		// post: add product

		connect();

		String insertString = "insert into Product values(?, ?, ?, ?)";
		preparedStatement = connection.prepareStatement(insertString);
		preparedStatement.setString(1, id);
		preparedStatement.setString(2, name);
		preparedStatement.setDouble(3, price);
		preparedStatement.setBoolean(4, onSale);
		preparedStatement.executeUpdate();

		// release resource
		disconnect();
	}


	//	UPDATE the price of a product
	//
	public static void updateProductPrice(String id, double price) throws Exception
	{
		Product product = searchProduct(id);
		boolean pre = (product != null);
		if(! pre)
		{
			String msg = "Product does not exist!";
			System.out.println("\nERROR: " + msg);
			throw new Exception(msg);
		}

		// post: update product's price

		connect();

		String updateString =
			"update Product " +
			"set price = ? " +
			"where id = ? ";

		preparedStatement = connection.prepareStatement(updateString);
		preparedStatement.setDouble(1, price);
		preparedStatement.setString(2, id);

		preparedStatement.executeUpdate();
		disconnect();
	}


	//	UPDATE the on sale status of a product
	//
	public static void updateProductOnSale(String id, boolean onSale) throws Exception
	{
		Product product = searchProduct(id);
		boolean pre = (product != null);
		if(! pre)
		{
			String msg = "Product does not exist!";
			System.out.println("\nERROR: " + msg);
			throw new Exception(msg);
		}

		// post: update product's sale status

		connect();

		String updateString =
			"update Product " +
			"set onSale = ? " +
			"where id = ? ";

		preparedStatement = connection.prepareStatement(updateString);
		preparedStatement.setBoolean(1, onSale);
		preparedStatement.setString(2, id);

		preparedStatement.executeUpdate();
		disconnect();
	}


	//	REMOVE a product
	//
	public static void removeProduct(String id) throws Exception
	{
		Product product = searchProduct(id);
		boolean pre = (product != null);
		if(! pre)
		{
			String msg= ">>> ERROR: Product does not exist!";
			System.out.println(msg);
			throw new Exception(msg);
		}

		connect();
		String deleteStatement =
			"delete from product " +
			"where id = ? ";
		preparedStatement = connection.prepareStatement(deleteStatement);
		preparedStatement.setString(1, id);
		preparedStatement.executeUpdate();

		disconnect();
	}


	// RETRIEVE products in a price range
	//
	public static ArrayList<Product> getProductsInPriceRange(double lower, double upper)
	throws SQLException
	{
		connect();

		String queryString =
			"select * from product where ? <= price and price <= ?";

		preparedStatement = connection.prepareStatement(queryString);
		preparedStatement.setDouble(1, lower);
		preparedStatement.setDouble(2, upper);
		ResultSet rs = preparedStatement.executeQuery();

		ArrayList<Product> products = new ArrayList<Product>();

		while (rs.next())
		{
			String id = rs.getString(1);
			String name = rs.getString(2);
			double price = rs.getDouble(3);
			boolean onSale = rs.getBoolean(4);

			products.add(new Product(id, name, price, onSale));
		}

		disconnect();

		return products;
	}

	// GET ALL products
	// We need this method to load data to the table view
	//
	public static List<Product> getAllProducts() throws Exception
	{
		connect();
		String queryString = "select * from Product";
		ResultSet rs = statement.executeQuery(queryString);

		ArrayList<Product> products = new ArrayList<Product>();

		while (rs.next())
		{
			String id = rs.getString(1);
			String name = rs.getString(2);
			double price = rs.getDouble(3);
			boolean onSale = rs.getBoolean(4);

			products.add(new Product(id, name, price, onSale));
		}

		disconnect();
		return products;
	}

	// TESTS. We can perform some quick tests
	//
	public static void main(String [] args) throws Exception
	{
		// run CreateCatalogDB.bat first to initialize the database
		//
		java.lang.Runtime rt = java.lang.Runtime.getRuntime();
		java.lang.Process process = rt.exec("CreateCatalogDB.bat");

		// search for some products to verify
		System.out.println("\nfind p20 " + CatalogDSC.searchProduct("p20"));
		System.out.println("\nfind p100 " + CatalogDSC.searchProduct("p100"));

		// add a product
		CatalogDSC.addProduct("p100", "TV", 1000.50, true);
		System.out.println("\nfind 100: " + CatalogDSC.searchProduct("p100") + "\n");

		// search for the new product to verify
		Product p = CatalogDSC.searchProduct("p100");
		System.out.println("\nProduct p100: " + p + "\n");

		// update a product's price
		CatalogDSC.updateProductPrice("p100", 2000.50);
		p = CatalogDSC.searchProduct("p100");
		System.out.println("\nProduct p100: "  + p + "\n");

		// update a product's sale status
		CatalogDSC.updateProductOnSale("p100", false);
		p = CatalogDSC.searchProduct("p100");
		System.out.println("\nProduct p100: "  + p + "\n");

		// remove a product
		CatalogDSC.removeProduct("p100");
		p = CatalogDSC.searchProduct("p100");
		System.out.println("\nProduct p100: "  + p + "\n");

		// search for products in a price range
		ArrayList<Product>  list = CatalogDSC.getProductsInPriceRange(0, 35);
		System.out.println(list+ "\n");

	} // end of main

} // end of class CatalogGUI
