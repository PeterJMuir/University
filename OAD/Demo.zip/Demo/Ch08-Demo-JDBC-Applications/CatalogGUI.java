import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.geometry.*;
import java.util.*;
import java.io.*;
import javafx.collections.*;
import javafx.collections.transformation.*;
import javafx.scene.control.cell.*;
import javafx.beans.property.*;

public class CatalogGUI extends Application
{
	public void start(Stage stage) throws Exception
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();

		Thread.currentThread().setUncaughtExceptionHandler((thread, exception) ->
		{
			System.out.println("ERROR: " + exception);
		});
	}

	public void addContents(Stage stage) throws Exception
	{
		// Det a VBox be the root node of the scene
		//	By defing it here, we can add the nodes to be displayed
		// as we go along
		//
		VBox root = new VBox();
		root.setSpacing(10);
		root.setStyle("-fx-background-color: wheat; -fx-font-size: 20");
		root.setAlignment(Pos.CENTER);


		// =============================================
		// Task 1 - Define the table data and table view
		// =============================================

		// Create table data (an observable list of objects)
		// and load data from the database (by calling a method in CatalogDSC)
		//
		ObservableList<Product> tableData= FXCollections.observableArrayList();
		tableData.addAll(CatalogDSC.getAllProducts());


		// =============================================
		// Task 2 - Define the table view
		// =============================================

		// Define table columns
		//
		TableColumn<Product, String> idColumn =
			new TableColumn<Product, String>("Id");

		idColumn.setCellValueFactory(
			new PropertyValueFactory<Product, String>("Id"));

		TableColumn<Product, String> nameColumn =
			new TableColumn<Product, String>("Name");
		nameColumn.setCellValueFactory(
			new PropertyValueFactory<Product, String>("Name"));

		TableColumn<Product, Double> priceColumn =
			new TableColumn<Product, Double>("Price");
		priceColumn.setCellValueFactory(
			new PropertyValueFactory<Product, Double>("Price"));

		TableColumn<Product, Boolean> onSaleColumn =
			new TableColumn<Product, Boolean>("OnSale");
		onSaleColumn.setCellValueFactory(
			new PropertyValueFactory<Product, Boolean>("OnSale"));


		// Create the table view and add table columns to it
		TableView<Product> tableView = new TableView<Product>();

		tableView.getColumns().add(idColumn);
		tableView.getColumns().add(nameColumn);
		tableView.getColumns().add(priceColumn);
		tableView.getColumns().add(onSaleColumn);

		//	Attach table data to the table view
		//
		tableView.setItems(tableData);

		// Can control the display of the table view
		tableView.setMinWidth(600);
		tableView.setMaxWidth(800);
		idColumn.setMinWidth(100);
		nameColumn.setMinWidth(100);
		priceColumn.setMinWidth(100);
		onSaleColumn.setMinWidth(100);

		//	Display table view(by adding it to the root node)
		root.getChildren().add(tableView);


		// ============================
		// Task 3 - Create a row filter
		// ============================

		// Create a text field to enter the filter string (on product name)
		//
		Label filterLB = new Label("Filter by Product Name: ");
		TextField filterTF = new TextField();
		HBox filterHBox = new HBox(filterLB, filterTF);
		root.getChildren().add(filterHBox);

		// Create a filteredList
		FilteredList<Product> filteredList =
			new FilteredList<>(tableData, p -> true);

		// Create a sorted list and wrap it around the filtered list
		// Bind the comparator prperty of the sorted list to that of the table view
		//	Let the table view shows the items of the sorted list
		//
		SortedList<Product> sortedList = new SortedList<>(filteredList);
		sortedList.comparatorProperty().bind(tableView.comparatorProperty());
		tableView.setItems(sortedList);

		// add a change listener to the text field
		// which set the predicate for the filer list
		// based on the value in the text field
		//
	  	filterTF.textProperty()
	  		.addListener((observable, oldValue, newValue) ->
	  		{
				filteredList.setPredicate(product ->
					{
				 		// If filter text is empty, display all products
				 		if (newValue == null || newValue.isEmpty())
				 		{
					  		return true;
				 		}

				 		// Compare product's name with filter text
				 		// If match, return true. Otherwise return false
				 		//
				 		String filterString = newValue.toUpperCase();

				 		if (product.getName().toUpperCase().contains(filterString))
				 		{
					  		return true;
						}
						else
						{
				 			return false;
						}
					});
		  });


		// =====================================================================
		// Task 4 - Add Customized Sorter
		// Sorts by name (in ascending order) and then price (in descending order)
		// IN ADDITION TO EXISTING SORTING ORDER IN OTHER COLUMNS IF ANY
		//
		// Also add button to unsort the table view
		// =====================================================================

		Button sortBT = new Button("Sort by Name and Price");
		sortBT.setOnAction((e) ->
			{
				nameColumn.setSortType(TableColumn.SortType.ASCENDING);
				priceColumn.setSortType(TableColumn.SortType.DESCENDING);
				tableView.getSortOrder().add(nameColumn);
				tableView.getSortOrder().add(priceColumn);
			});

		Button unsortBT = new Button("Restore Original Order");
		unsortBT.setOnAction((e) ->
			{
				tableView.getSortOrder().clear();
			});

		HBox sortHBox = new HBox(sortBT, unsortBT);
		root.getChildren().add(sortHBox);

		// ===================================================================
		// Task 5 - Create Work Area
		// ===================================================================

		Label idLB = new Label("Product ID: ");
		TextField idTF = new TextField();

		Label nameLB = new Label("Name: ");
		TextField nameTF = new TextField();

		Label priceLB = new Label("Price: ");
		TextField priceTF = new TextField();

		Label onSaleLB = new Label("On Sale: ");
		TextField onSaleTF = new TextField();

		HBox workAreaHBox = new HBox();
		workAreaHBox.getChildren().addAll(idLB, idTF, nameLB, nameTF,
			priceLB, priceTF, onSaleLB, onSaleTF);
		root.getChildren().add(workAreaHBox);


		//	==================================================================
		//	Task 6 - Create button to copy selected row
		// ==================================================================
		Button copyBT = new Button("Copy Selected Product");
		root.getChildren().add(copyBT);

		copyBT.setOnAction(e ->
			{
				Product p = tableView.getSelectionModel().getSelectedItem();
				idTF.setText(p.getId());
				nameTF.setText(p.getName());
				priceTF.setText(new String() + p.getPrice());
				onSaleTF.setText(new String() + p.isOnSale());
			});


		// ===================================================================
		// Task 7 - Create buttons to add, update and delete product
		// ====================================================================


		Button addBT = new Button("Add Product");
		Button updateBT = new Button("Update Price, On Sale");
		Button deleteBT = new Button("Delete Product");

		HBox addUpdateDeleteHBox = new HBox();
		addUpdateDeleteHBox.getChildren().addAll(addBT, updateBT, deleteBT);
		root.getChildren().add(addUpdateDeleteHBox);

		addBT.setOnAction(e ->
			{
				try
				{
					// Get input values
					String id = idTF.getText().trim();
					String name = nameTF.getText().trim();
					double price = Double.parseDouble(priceTF.getText().trim());
					boolean onSale= Boolean.parseBoolean(onSaleTF.getText().trim());

					// add to both catalog and table data
					//
					CatalogDSC.addProduct(id, name, price, onSale);
					tableData.add(new Product(id, name, price, onSale));

					System.out.println("\nAFTER Add / table data:\n" + tableData);
					System.out.println("\nAFTER Add / catalog:\n"
						+ CatalogDSC.getAllProducts());
				}
				catch(Exception exception)
				{
					throw new RuntimeException(exception.getMessage());
				}

			});

		updateBT.setOnAction((e) ->
			{
				try
				{
					String id = idTF.getText();
					double price = Double.parseDouble(priceTF.getText().trim());
					boolean onSale= Boolean.parseBoolean(onSaleTF.getText().trim());

					CatalogDSC.updateProductPrice(id, price);
					CatalogDSC.updateProductOnSale(id, onSale);

					for(Product p: tableData)
					{
						if(p.getId().equals(id))
						{
							p.setPrice(price);
							p.setOnSale(onSale);

							// Refresh the column to see the change
							// (This is a work around)
							tableView.getColumns().get(0).setVisible(false);
							tableView.getColumns().get(0).setVisible(true);

							break;
						}
					}

					System.out.println("\nAFTER Update / table data:\n" + tableData);
					System.out.println("\nAFTER Update / catalog:\n"
						+ CatalogDSC.getAllProducts());
				}
				catch(Exception exception)
				{
					throw new RuntimeException(exception.getMessage());
				}
			});


		deleteBT.setOnAction((e) ->
		{
			try
			{
				Product selectedProduct = tableView.getSelectionModel().getSelectedItem();
				CatalogDSC.removeProduct(selectedProduct.getId());
				tableData.remove(selectedProduct);
				System.out.println("\nAFTER Delete / table data:\n" + tableData);
				System.out.println("\nAFTER Delete / catalog:\n"
					+ CatalogDSC.getAllProducts());
			}
			catch(Exception exception)
			{
				throw new RuntimeException(exception.getMessage());
			}
		});


		// =====================================================================
		// SET UP and SHOW the Stage
		// =====================================================================
		// Create scene and set stage

		Scene scene = new Scene(root);
		stage.setScene(scene);
	}
}