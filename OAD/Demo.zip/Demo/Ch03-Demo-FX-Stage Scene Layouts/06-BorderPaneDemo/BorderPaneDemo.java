import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.geometry.*;		// Pos, Insets

public class BorderPaneDemo extends Application
{

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.sizeToScene();
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Define controls and layout
		Label topLB = new Label("TOP Label ");
		topLB.setFont(Font.font("Arial", 20));
		topLB.setStyle("-fx-border-style: solid;"); 	// draw border

		Label bottomLB = new Label("BOTTOM Label");
		bottomLB.setFont(Font.font("Arial", 20));
		bottomLB.setStyle("-fx-border-style: solid;");

		Label leftLB = new Label("LEFT Label");
		leftLB.setFont(Font.font("Arial", 20));
		leftLB.setStyle("-fx-border-style: solid;");

		Label rightLB = new Label("RIGHT Label");
		rightLB.setFont(Font.font("Arial", 20));
		rightLB.setStyle("-fx-border-style: solid;");

		Label centerLB = new Label("CENTER Label");
		centerLB.setFont(Font.font("Arial", 20));
		centerLB.setStyle("-fx-border-style: solid;");

		BorderPane pane = new BorderPane();
		pane.setTop(topLB);
		pane.setBottom(bottomLB);
		pane.setLeft(leftLB);
		pane.setRight(rightLB);
		pane.setCenter(centerLB);

			// To display the top label in the center of the top
			// region, uncomment the following statement
			// pane.setAlignment(bottomLB, Pos.CENTER);


		//	Set scene and stage
		Scene scene = new Scene(pane, 400, 400);
		stage.setScene(scene);
	}
}
