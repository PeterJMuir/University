import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.geometry.*;		// Pos, Insets

public class HBoxDemo extends Application
{
	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Define controls and layout
		Label l1 = new Label("Label 1");
		l1.setFont(Font.font("Arial", 10));
		l1.setStyle(
			"-fx-border-style: solid;" +			// draw border
			"-fx-background-color: yellow;");	// set background color

		Label l2 = new Label("Label 2");
		l2.setFont(Font.font("Arial", 20));
		l2.setStyle("-fx-border-style: solid;");

		Label l3 = new Label("Label 3");
		l3.setFont(Font.font("Arial", 30));
		l3.setStyle("-fx-border-style: solid;");

		HBox hbox = new HBox(l1, l2, l3);

		hbox.setSpacing(10);

		// hbox.setAlignment(Pos.CENTER);
		// hbox.setAlignment(Pos.TOP_CENTER);
		// hbox.setAlignment(Pos.BOTTOM_CENTER);
		// hbox.setAlignment(Pos.BOTTOM_RIGHT);

		// hbox.setStyle("-fx-border-style: solid;");
		// hbox.setMargin(l1, new Insets(10, 20, 30, 40));
		// hbox.setPadding(new Insets(10, 20, 30, 40));

		//	Set scene and stage
		Scene scene = new Scene(hbox, 400, 300);
		stage.setScene(scene);
	}
}
