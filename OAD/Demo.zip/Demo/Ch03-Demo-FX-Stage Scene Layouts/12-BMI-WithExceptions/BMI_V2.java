import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.scene.paint.*;	// e.g. Color
import javafx.geometry.*;

import java.io.*;		// File
import java.util.*;	// Scanner

public class BMI_V2 extends Application
{
	public void start(Stage stage)
	{
		// To catch uncaught exceptions
		// Thread.currentThread) is the FX Application thread
		Thread.currentThread().setUncaughtExceptionHandler((thread, exception) ->
		 	{
		   	System.out.println("ERROR: " + exception);
        	});

		stage.setTitle(getClass().getName());
		addContents(stage);
		stage.show();
	}

	public void addContents(Stage stage) // throws Exception
	{
		// Define controls
		Text header = new Text("BMI Calculator");
		header.setFont(new Font(40));

		Label heightLB = new Label("Enter your height (in cm): ");
		TextField heightTF = new TextField();

		Label weightLB = new Label("Enter your weight (in kg): ");
		TextField weightTF = new TextField();

		Button calculateBT = new Button("Calculate BMI");

		Label bmiLB = new Label("Your BMI will be displayed here");

		calculateBT.setOnAction(e ->
			{
				double height = Double.parseDouble(heightTF.getText().trim())/100;
				int weight = Integer.parseInt(weightTF.getText().trim());
				double bmi = weight / (height * height);
				bmiLB.setText("Your bmi is: " + String.format("%.2f", bmi));
			});

		TextArea infoTA = new TextArea();
		infoTA.appendText(
			"\nA BMI of 18.5 to 25 may indicate optimal weight\n" +
			"A BMI lower than 18.5 suggests the person is underweight\n" +
			"A BMI above 25 may indicate the person is overweight\n" +
			"A BMI above 30 suggests the person is obese");

		infoTA.setPrefColumnCount(30);
		infoTA.setPrefRowCount(6);

		// Define layout

		HBox h1 = new HBox();
		HBox h2 = new HBox();
		HBox h3 = new HBox();
		HBox h4 = new HBox();
		HBox h5 = new HBox();
		HBox h6 = new HBox();
		VBox vbox = new VBox();

		h1.getChildren().addAll(header);
		h1.setAlignment(Pos.CENTER);
		h2.getChildren().addAll(heightLB, heightTF);
		h3.getChildren().addAll(weightLB, weightTF);
		h4.getChildren().addAll(calculateBT);
		h5.getChildren().addAll(bmiLB);
		h6.getChildren().addAll(infoTA);

		vbox.getChildren().addAll(h1, h2,h3, h4, h5, h6);

		vbox.setSpacing(10);
		h4.setAlignment(Pos.CENTER);

		//	Set scene and stage
		Scene scene = new Scene(vbox);
		stage.setScene(scene);
		stage.setResizable(false);
	}
}
