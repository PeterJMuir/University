import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

public class MultipleStages extends Application
{
	private int count = 0;

	public void start(Stage primaryStage)
	{
		addContents(primaryStage);
		primaryStage.setTitle(getClass().getName());
		primaryStage.show();
	}

	public void addContents(Stage primaryStage)
	{
		// Define controls and layout
		Label mainLB = new Label("Main");
		mainLB.setFont(Font.font("Arial", 40));

		Button option1BT = new Button("Option 1");
		option1BT.setOnAction((e) ->
			{
				Option1Stage.show(primaryStage.getX(), primaryStage.getY());
			});

		VBox box = new VBox();
		box.getChildren().addAll(mainLB, option1BT);

		//	Set scene and stage
		Scene scene = new Scene(box, 400, 300);
		primaryStage.setScene(scene);
	}
}
