import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;
import javafx.scene.text.*;

public class Option1Stage
{
	public static void show(double parentX, double parentY)
	{
		Stage stage = new Stage();
		stage.initStyle(StageStyle.UTILITY);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setMinWidth(250);
		stage.setX(parentX + 300);
		stage.setY(parentY + 200);

				// To create a stage without the close button
				// we need to use
				//		stage.initStyle(StageStyle.UNDECORATED);
				// Then we don't have a title bar. But the stage
				// also lose the border

		Label label = new Label("Option 1");
		label.setFont(Font.font("Arial", 40));

		Button exitBT = new Button("EXIT");
		exitBT.setOnAction(e -> stage.close());

		VBox box = new VBox(20);
		box.getChildren().addAll(label, exitBT);
		box.setAlignment(Pos.CENTER);

				// if we use Utility.UNDECORATED
				// we don't have the border around the stage either
				// One way to get the border is to draw the border
				// around the box (the root node of the scene)
				//		box.setStyle("-fx-border-style:solid;"
				//			+ "-fx-background-color:lightgray;"
				//			+ "-fx-padding: 10px");

		Scene scene = new Scene(box);
		stage.setScene(scene);

		/*	Does not work!
		stage.setOnCloseRequest((e) ->
			{
				System.out.println("???");
				try
				{
					throw new RuntimeException();
				}
				catch(Exception exc){}
			});
		*/
		stage.show();
	}
}
