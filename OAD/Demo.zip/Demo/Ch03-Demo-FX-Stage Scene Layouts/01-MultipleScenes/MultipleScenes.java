import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

public class MultipleScenes extends Application
{
	private Stage stage;
	private Scene mainScene;
	private Scene option1Scene;

	public void start(Stage stage)
	{
		addContents(stage);
		stage.setTitle(getClass().getName());
		stage.show();
	}

	public void addContents(Stage stage)
	{
		// Make attribute stage refer to the primary Stage instance that
		// the runtime system creates
		this.stage = stage;

		// Define the scenes
		setMainScene();
		setOption1Scene();

		// Intially let the stage show the main scene
		stage.setScene(mainScene);
	}

	private void setMainScene()
	{
		Label sceneLB = new Label("Main");
		sceneLB.setFont(Font.font("Arial", 40));

		Button option1BT = new Button("Option 1");
		option1BT.setOnAction((e) ->
			{
				stage.setScene(option1Scene);
			});
		VBox box = new VBox();
		box.getChildren().addAll(sceneLB, option1BT);

		mainScene = new Scene(box, 400, 300);
	}

	private void setOption1Scene()
	{
		Label sceneLB = new Label("Option 1");
		sceneLB.setFont(Font.font("Arial", 40));

		Button mainBT = new Button("Back to Main");
		mainBT.setOnAction((e) ->
			{
				stage.setScene(mainScene);
			});
		VBox box = new VBox();
		box.getChildren().addAll(sceneLB, mainBT);

		option1Scene = new Scene(box, 400, 300);
	}
}
